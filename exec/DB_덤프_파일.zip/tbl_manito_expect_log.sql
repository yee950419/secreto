create table tbl_manito_expect_log
(
    expected_at          datetime(6) null,
    expected_user        bigint      null,
    manito_expect_log_no bigint auto_increment
        primary key,
    room_user_no         bigint      null,
    expected_reason      text        null,
    constraint FKdebpqy76kyuffdmorkq1fwsrs
        foreign key (room_user_no) references tbl_room_user (room_user_no)
);

INSERT INTO manitodb.tbl_manito_expect_log (expected_at, expected_user, room_user_no, expected_reason) VALUES ('2024-02-15 22:21:08.798955', 316, 321, '관상이 마니또상임');
INSERT INTO manitodb.tbl_manito_expect_log (expected_at, expected_user, room_user_no, expected_reason) VALUES ('2024-02-15 23:02:49.231167', 314, 307, '당신이 마니또야');
INSERT INTO manitodb.tbl_manito_expect_log (expected_at, expected_user, room_user_no, expected_reason) VALUES ('2024-02-15 23:08:46.388615', 319, 316, '');
INSERT INTO manitodb.tbl_manito_expect_log (expected_at, expected_user, room_user_no, expected_reason) VALUES ('2024-02-15 23:08:58.495031', 317, 316, '');
INSERT INTO manitodb.tbl_manito_expect_log (expected_at, expected_user, room_user_no, expected_reason) VALUES ('2024-02-15 23:12:20.245601', 321, 316, '');
INSERT INTO manitodb.tbl_manito_expect_log (expected_at, expected_user, room_user_no, expected_reason) VALUES ('2024-02-15 23:12:26.581208', 317, 316, '');
INSERT INTO manitodb.tbl_manito_expect_log (expected_at, expected_user, room_user_no, expected_reason) VALUES ('2024-02-15 23:24:47.580617', 332, 330, '');
INSERT INTO manitodb.tbl_manito_expect_log (expected_at, expected_user, room_user_no, expected_reason) VALUES ('2024-02-15 23:24:53.123211', 330, 331, 'ㅋㅋ');
INSERT INTO manitodb.tbl_manito_expect_log (expected_at, expected_user, room_user_no, expected_reason) VALUES ('2024-02-15 23:24:57.724773', 329, 327, '마니또?');
INSERT INTO manitodb.tbl_manito_expect_log (expected_at, expected_user, room_user_no, expected_reason) VALUES ('2024-02-15 23:43:07.637420', 333, 339, '잘생겨서 ㅎㅎ');
INSERT INTO manitodb.tbl_manito_expect_log (expected_at, expected_user, room_user_no, expected_reason) VALUES ('2024-02-15 23:45:03.870706', 334, 333, '마니또!');
INSERT INTO manitodb.tbl_manito_expect_log (expected_at, expected_user, room_user_no, expected_reason) VALUES ('2024-02-16 00:05:12.290997', 343, 342, '너가 내 마니또같애');
INSERT INTO manitodb.tbl_manito_expect_log (expected_at, expected_user, room_user_no, expected_reason) VALUES ('2024-02-16 00:05:26.418912', 343, 340, '');
INSERT INTO manitodb.tbl_manito_expect_log (expected_at, expected_user, room_user_no, expected_reason) VALUES ('2024-02-16 00:05:51.200871', 344, 345, '너가 범인이지?');
INSERT INTO manitodb.tbl_manito_expect_log (expected_at, expected_user, room_user_no, expected_reason) VALUES ('2024-02-16 00:14:06.787919', 348, 351, '');
INSERT INTO manitodb.tbl_manito_expect_log (expected_at, expected_user, room_user_no, expected_reason) VALUES ('2024-02-16 00:14:22.536525', 347, 348, '상학이형이 내 마니또지??');
INSERT INTO manitodb.tbl_manito_expect_log (expected_at, expected_user, room_user_no, expected_reason) VALUES ('2024-02-16 00:14:54.380556', 347, 349, '일 잘하게 생김');
INSERT INTO manitodb.tbl_manito_expect_log (expected_at, expected_user, room_user_no, expected_reason) VALUES ('2024-02-16 00:31:25.353356', 360, 358, '');
INSERT INTO manitodb.tbl_manito_expect_log (expected_at, expected_user, room_user_no, expected_reason) VALUES ('2024-02-16 00:31:30.202377', 358, 361, '잘생겨서 ㅎㅎ');
INSERT INTO manitodb.tbl_manito_expect_log (expected_at, expected_user, room_user_no, expected_reason) VALUES ('2024-02-16 00:31:38.865701', 360, 362, '너가 내 마니또아니냐??');
INSERT INTO manitodb.tbl_manito_expect_log (expected_at, expected_user, room_user_no, expected_reason) VALUES ('2024-02-16 00:31:39.213391', 360, 363, '마니또인듯');
INSERT INTO manitodb.tbl_manito_expect_log (expected_at, expected_user, room_user_no, expected_reason) VALUES ('2024-02-16 00:31:45.782444', 361, 359, '관상이 마니또상임');
INSERT INTO manitodb.tbl_manito_expect_log (expected_at, expected_user, room_user_no, expected_reason) VALUES ('2024-02-16 00:31:49.840849', 362, 360, '이사람임');
INSERT INTO manitodb.tbl_manito_expect_log (expected_at, expected_user, room_user_no, expected_reason) VALUES ('2024-02-16 00:31:54.302152', 362, 358, '마니또인 것 같음...');
INSERT INTO manitodb.tbl_manito_expect_log (expected_at, expected_user, room_user_no, expected_reason) VALUES ('2024-02-16 00:55:23.346637', 335, 365, 'ㅋㅋㅋㅋㅋ');
INSERT INTO manitodb.tbl_manito_expect_log (expected_at, expected_user, room_user_no, expected_reason) VALUES ('2024-02-16 00:56:59.231445', 365, 335, '고구마 당신이 내 마니또야!');
INSERT INTO manitodb.tbl_manito_expect_log (expected_at, expected_user, room_user_no, expected_reason) VALUES ('2024-02-16 01:10:41.389601', 370, 372, '헬로우월드');
INSERT INTO manitodb.tbl_manito_expect_log (expected_at, expected_user, room_user_no, expected_reason) VALUES ('2024-02-16 01:14:09.125412', 370, 369, '마니또다!');
