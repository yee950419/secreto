create table tbl_sudden_mission
(
    mission_submit_at datetime(6) null,
    room_no           bigint      null,
    sudden_mission_no bigint auto_increment
        primary key,
    content           text        null,
    constraint FK89d1ert9vn34dgicqqi1kfjnw
        foreign key (room_no) references tbl_room (room_no)
);

INSERT INTO manitodb.tbl_sudden_mission (mission_submit_at, room_no, content) VALUES ('2024-02-15 21:18:30.325478', 108, '자신을 맞출 수 있게 힌트 하나 알려주기');
INSERT INTO manitodb.tbl_sudden_mission (mission_submit_at, room_no, content) VALUES ('2024-02-15 21:19:59.504550', 108, '처음봤을 때 느꼈던 첫 인상 이야기 해주기');
INSERT INTO manitodb.tbl_sudden_mission (mission_submit_at, room_no, content) VALUES ('2024-02-15 21:20:49.893742', 108, '오늘 먹었던 점심 인증하기');
INSERT INTO manitodb.tbl_sudden_mission (mission_submit_at, room_no, content) VALUES ('2024-02-15 21:21:56.015343', 108, '개인적으로 먹어봤으면 하는 음식 말해주기');
INSERT INTO manitodb.tbl_sudden_mission (mission_submit_at, room_no, content) VALUES ('2024-02-15 21:22:58.996526', 108, '나의 비밀친구에게 맛있는 과자 챙겨주기');
INSERT INTO manitodb.tbl_sudden_mission (mission_submit_at, room_no, content) VALUES ('2024-02-15 22:16:40.869143', 109, '마니띠만의 장점 말해주기!');
INSERT INTO manitodb.tbl_sudden_mission (mission_submit_at, room_no, content) VALUES ('2024-02-15 22:17:34.266786', 109, '마니띠의 첫인상 말해보기');
INSERT INTO manitodb.tbl_sudden_mission (mission_submit_at, room_no, content) VALUES ('2024-02-15 22:17:36.984935', 109, '마니띠의 첫인상 말해보기');
INSERT INTO manitodb.tbl_sudden_mission (mission_submit_at, room_no, content) VALUES ('2024-02-15 22:18:47.586238', 109, '좋아하는 노래 추천해주기');
INSERT INTO manitodb.tbl_sudden_mission (mission_submit_at, room_no, content) VALUES ('2024-02-15 22:21:03.548560', 109, '커피 한 잔 사주기');
INSERT INTO manitodb.tbl_sudden_mission (mission_submit_at, room_no, content) VALUES ('2024-02-15 22:21:55.811969', 109, '노래 한 곡 불러주기');
INSERT INTO manitodb.tbl_sudden_mission (mission_submit_at, room_no, content) VALUES ('2024-02-15 22:23:22.017477', 109, '아이스버킷 챌린지');
INSERT INTO manitodb.tbl_sudden_mission (mission_submit_at, room_no, content) VALUES ('2024-02-15 22:24:05.521208', 109, '1일 1커밋 운동');
INSERT INTO manitodb.tbl_sudden_mission (mission_submit_at, room_no, content) VALUES ('2024-02-15 22:24:39.267392', 109, '오버워치 경쟁전 돌리기');
INSERT INTO manitodb.tbl_sudden_mission (mission_submit_at, room_no, content) VALUES ('2024-02-15 22:26:07.959070', 109, '123');
INSERT INTO manitodb.tbl_sudden_mission (mission_submit_at, room_no, content) VALUES ('2024-02-15 22:27:02.232951', 109, '456');
INSERT INTO manitodb.tbl_sudden_mission (mission_submit_at, room_no, content) VALUES ('2024-02-15 22:29:58.017587', 109, '돌발미션 테스트');
INSERT INTO manitodb.tbl_sudden_mission (mission_submit_at, room_no, content) VALUES ('2024-02-15 22:30:07.794100', 109, '돌발미션 테스트2');
INSERT INTO manitodb.tbl_sudden_mission (mission_submit_at, room_no, content) VALUES ('2024-02-15 22:30:53.408774', 109, '돌발미션 테스트3');
INSERT INTO manitodb.tbl_sudden_mission (mission_submit_at, room_no, content) VALUES ('2024-02-15 22:34:01.952912', 109, '123');
INSERT INTO manitodb.tbl_sudden_mission (mission_submit_at, room_no, content) VALUES ('2024-02-15 22:39:05.553766', 109, '돌발 미션2');
INSERT INTO manitodb.tbl_sudden_mission (mission_submit_at, room_no, content) VALUES ('2024-02-15 22:39:53.473832', 109, '123');
INSERT INTO manitodb.tbl_sudden_mission (mission_submit_at, room_no, content) VALUES ('2024-02-15 22:39:57.156707', 109, '123');
INSERT INTO manitodb.tbl_sudden_mission (mission_submit_at, room_no, content) VALUES ('2024-02-15 22:41:41.923822', 109, '3221');
INSERT INTO manitodb.tbl_sudden_mission (mission_submit_at, room_no, content) VALUES ('2024-02-15 22:42:15.537074', 109, '123');
INSERT INTO manitodb.tbl_sudden_mission (mission_submit_at, room_no, content) VALUES ('2024-02-15 22:42:18.977151', 109, '32222');
INSERT INTO manitodb.tbl_sudden_mission (mission_submit_at, room_no, content) VALUES ('2024-02-15 22:42:20.980365', 109, '32222');
INSERT INTO manitodb.tbl_sudden_mission (mission_submit_at, room_no, content) VALUES ('2024-02-15 22:47:47.759190', 109, '돌발 미션 테스트! 1');
INSERT INTO manitodb.tbl_sudden_mission (mission_submit_at, room_no, content) VALUES ('2024-02-15 22:47:53.568090', 109, '돌발 미션 테스트! 2');
INSERT INTO manitodb.tbl_sudden_mission (mission_submit_at, room_no, content) VALUES ('2024-02-15 22:48:00.724847', 109, '돌발 미션 테스트! 3');
INSERT INTO manitodb.tbl_sudden_mission (mission_submit_at, room_no, content) VALUES ('2024-02-15 22:48:10.438200', 109, '돌발 미션 테스트! 4');
INSERT INTO manitodb.tbl_sudden_mission (mission_submit_at, room_no, content) VALUES ('2024-02-15 22:48:15.291162', 109, '돌발 미션 테스트! 5');
INSERT INTO manitodb.tbl_sudden_mission (mission_submit_at, room_no, content) VALUES ('2024-02-15 22:48:25.738315', 109, '돌발 미션 테스트! 6');
INSERT INTO manitodb.tbl_sudden_mission (mission_submit_at, room_no, content) VALUES ('2024-02-15 22:49:00.292566', 109, '123');
INSERT INTO manitodb.tbl_sudden_mission (mission_submit_at, room_no, content) VALUES ('2024-02-15 22:49:03.518681', 109, '123');
INSERT INTO manitodb.tbl_sudden_mission (mission_submit_at, room_no, content) VALUES ('2024-02-15 22:49:05.599673', 109, '333');
INSERT INTO manitodb.tbl_sudden_mission (mission_submit_at, room_no, content) VALUES ('2024-02-15 22:49:07.678164', 109, '444');
INSERT INTO manitodb.tbl_sudden_mission (mission_submit_at, room_no, content) VALUES ('2024-02-15 22:49:09.521090', 109, '555');
INSERT INTO manitodb.tbl_sudden_mission (mission_submit_at, room_no, content) VALUES ('2024-02-15 22:49:16.441592', 109, '111');
INSERT INTO manitodb.tbl_sudden_mission (mission_submit_at, room_no, content) VALUES ('2024-02-15 22:49:18.139303', 109, '222');
INSERT INTO manitodb.tbl_sudden_mission (mission_submit_at, room_no, content) VALUES ('2024-02-15 22:49:20.161585', 109, '333');
INSERT INTO manitodb.tbl_sudden_mission (mission_submit_at, room_no, content) VALUES ('2024-02-15 22:49:21.845696', 109, '444');
INSERT INTO manitodb.tbl_sudden_mission (mission_submit_at, room_no, content) VALUES ('2024-02-15 22:49:23.713858', 109, '555');
INSERT INTO manitodb.tbl_sudden_mission (mission_submit_at, room_no, content) VALUES ('2024-02-15 22:49:25.597121', 109, '666');
INSERT INTO manitodb.tbl_sudden_mission (mission_submit_at, room_no, content) VALUES ('2024-02-15 22:49:27.901298', 109, '777');
INSERT INTO manitodb.tbl_sudden_mission (mission_submit_at, room_no, content) VALUES ('2024-02-15 22:49:30.144654', 109, '888');
INSERT INTO manitodb.tbl_sudden_mission (mission_submit_at, room_no, content) VALUES ('2024-02-15 22:49:32.311177', 109, '999');
INSERT INTO manitodb.tbl_sudden_mission (mission_submit_at, room_no, content) VALUES ('2024-02-15 22:49:34.965872', 109, '000');
INSERT INTO manitodb.tbl_sudden_mission (mission_submit_at, room_no, content) VALUES ('2024-02-15 22:49:50.222046', 109, '1');
INSERT INTO manitodb.tbl_sudden_mission (mission_submit_at, room_no, content) VALUES ('2024-02-15 22:49:52.722832', 109, '2');
INSERT INTO manitodb.tbl_sudden_mission (mission_submit_at, room_no, content) VALUES ('2024-02-15 22:49:54.629099', 109, '3');
INSERT INTO manitodb.tbl_sudden_mission (mission_submit_at, room_no, content) VALUES ('2024-02-15 22:49:56.766015', 109, '4');
INSERT INTO manitodb.tbl_sudden_mission (mission_submit_at, room_no, content) VALUES ('2024-02-15 22:49:58.759531', 109, '5');
INSERT INTO manitodb.tbl_sudden_mission (mission_submit_at, room_no, content) VALUES ('2024-02-15 22:50:00.793528', 109, '6');
INSERT INTO manitodb.tbl_sudden_mission (mission_submit_at, room_no, content) VALUES ('2024-02-15 22:50:02.888360', 109, '7');
INSERT INTO manitodb.tbl_sudden_mission (mission_submit_at, room_no, content) VALUES ('2024-02-15 22:50:04.917882', 109, '8');
INSERT INTO manitodb.tbl_sudden_mission (mission_submit_at, room_no, content) VALUES ('2024-02-15 22:50:07.026085', 109, '9');
INSERT INTO manitodb.tbl_sudden_mission (mission_submit_at, room_no, content) VALUES ('2024-02-15 22:50:09.122675', 109, '0');
INSERT INTO manitodb.tbl_sudden_mission (mission_submit_at, room_no, content) VALUES ('2024-02-15 22:50:35.181861', 109, '1');
INSERT INTO manitodb.tbl_sudden_mission (mission_submit_at, room_no, content) VALUES ('2024-02-15 22:50:37.777530', 109, '2');
INSERT INTO manitodb.tbl_sudden_mission (mission_submit_at, room_no, content) VALUES ('2024-02-15 22:50:40.388577', 109, '3');
INSERT INTO manitodb.tbl_sudden_mission (mission_submit_at, room_no, content) VALUES ('2024-02-15 22:50:42.540913', 109, '4');
INSERT INTO manitodb.tbl_sudden_mission (mission_submit_at, room_no, content) VALUES ('2024-02-15 22:50:44.641220', 109, '5');
INSERT INTO manitodb.tbl_sudden_mission (mission_submit_at, room_no, content) VALUES ('2024-02-15 22:50:56.666340', 109, '1');
INSERT INTO manitodb.tbl_sudden_mission (mission_submit_at, room_no, content) VALUES ('2024-02-15 22:52:31.320430', 109, '1');
INSERT INTO manitodb.tbl_sudden_mission (mission_submit_at, room_no, content) VALUES ('2024-02-15 22:52:33.655596', 109, '2');
INSERT INTO manitodb.tbl_sudden_mission (mission_submit_at, room_no, content) VALUES ('2024-02-15 22:52:36.666642', 109, '3');
INSERT INTO manitodb.tbl_sudden_mission (mission_submit_at, room_no, content) VALUES ('2024-02-15 22:52:39.265908', 109, '4');
INSERT INTO manitodb.tbl_sudden_mission (mission_submit_at, room_no, content) VALUES ('2024-02-15 22:52:41.930961', 109, '5');
INSERT INTO manitodb.tbl_sudden_mission (mission_submit_at, room_no, content) VALUES ('2024-02-15 22:52:44.454665', 109, '6');
INSERT INTO manitodb.tbl_sudden_mission (mission_submit_at, room_no, content) VALUES ('2024-02-15 22:52:46.509191', 109, '7');
INSERT INTO manitodb.tbl_sudden_mission (mission_submit_at, room_no, content) VALUES ('2024-02-15 22:52:48.598850', 109, '8');
INSERT INTO manitodb.tbl_sudden_mission (mission_submit_at, room_no, content) VALUES ('2024-02-15 22:52:50.269936', 109, '9');
INSERT INTO manitodb.tbl_sudden_mission (mission_submit_at, room_no, content) VALUES ('2024-02-15 22:52:51.560257', 109, '0');
INSERT INTO manitodb.tbl_sudden_mission (mission_submit_at, room_no, content) VALUES ('2024-02-15 22:52:56.313557', 109, '1');
INSERT INTO manitodb.tbl_sudden_mission (mission_submit_at, room_no, content) VALUES ('2024-02-15 22:52:58.298564', 109, '2');
INSERT INTO manitodb.tbl_sudden_mission (mission_submit_at, room_no, content) VALUES ('2024-02-15 22:53:00.565145', 109, '3');
INSERT INTO manitodb.tbl_sudden_mission (mission_submit_at, room_no, content) VALUES ('2024-02-15 23:01:29.107218', 109, '최애 노래 추천해주기');
INSERT INTO manitodb.tbl_sudden_mission (mission_submit_at, room_no, content) VALUES ('2024-02-15 23:22:48.846196', 111, '내가 좋아하는 노래 추천하기!');
INSERT INTO manitodb.tbl_sudden_mission (mission_submit_at, room_no, content) VALUES ('2024-02-15 23:43:09.716845', 113, '좋아하는 노래 추천하기');
INSERT INTO manitodb.tbl_sudden_mission (mission_submit_at, room_no, content) VALUES ('2024-02-16 00:15:02.588341', 116, '좋아하는 음식 물어보기');
INSERT INTO manitodb.tbl_sudden_mission (mission_submit_at, room_no, content) VALUES ('2024-02-16 00:15:09.380684', 116, 'MBTI 물어보기');
INSERT INTO manitodb.tbl_sudden_mission (mission_submit_at, room_no, content) VALUES ('2024-02-16 00:15:30.621610', 116, '가장 기억에 남는 여행지 물어보기');
INSERT INTO manitodb.tbl_sudden_mission (mission_submit_at, room_no, content) VALUES ('2024-02-16 00:28:49.557858', 118, '가장 좋아하는 음식 물어보기');
INSERT INTO manitodb.tbl_sudden_mission (mission_submit_at, room_no, content) VALUES ('2024-02-16 00:53:37.898528', 114, '최애 음악 추천해주기');
INSERT INTO manitodb.tbl_sudden_mission (mission_submit_at, room_no, content) VALUES ('2024-02-16 01:10:37.814415', 120, '최애 음악 추천해주기');
