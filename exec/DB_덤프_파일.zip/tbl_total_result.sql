create table tbl_total_result
(
    correct_user_count      int    not null,
    user_count              int    not null,
    fastest_correct_user_no bigint null,
    most_liked_board_no     bigint null,
    most_writed_user        bigint null,
    room_no                 bigint null,
    total_result_no         bigint auto_increment
        primary key,
    constraint UK_jw8rk7n2f7kn9wa68eeo62gr
        unique (room_no),
    constraint FK417q74g00pbl5q3ckewt3gnvd
        foreign key (room_no) references tbl_room (room_no)
);

