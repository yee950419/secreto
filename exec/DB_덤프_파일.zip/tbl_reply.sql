create table tbl_reply
(
    anonymity_yn    tinyint(1)   null,
    board_no        bigint       null,
    parent_reply_no bigint       null,
    register_at     datetime(6)  null,
    reply_no        bigint auto_increment
        primary key,
    tag_user_no     bigint       null,
    content         text         null,
    writer          varchar(255) null,
    room_user_no    bigint       null,
    delete_yn       bit          null,
    update_yn       bit          null,
    constraint FKerfyyqusi86vtw751tgaqjf2g
        foreign key (room_user_no) references tbl_room_user (room_user_no),
    constraint FKhx59f14b01p0nrs8f3bh56ep0
        foreign key (board_no) references tbl_board (board_no)
);

INSERT INTO manitodb.tbl_reply (anonymity_yn, board_no, parent_reply_no, register_at, tag_user_no, content, writer, room_user_no, delete_yn, update_yn) VALUES (0, 52, null, '2024-02-15 22:23:18.035097', null, '저는요', null, 317, false, null);
INSERT INTO manitodb.tbl_reply (anonymity_yn, board_no, parent_reply_no, register_at, tag_user_no, content, writer, room_user_no, delete_yn, update_yn) VALUES (0, 227, null, '2024-02-15 23:44:03.585299', null, '오리날다', null, 334, false, null);
INSERT INTO manitodb.tbl_reply (anonymity_yn, board_no, parent_reply_no, register_at, tag_user_no, content, writer, room_user_no, delete_yn, update_yn) VALUES (0, 227, null, '2024-02-15 23:54:58.447788', null, '오리 고기는 먹어야 제 맛이지', null, 339, false, null);
INSERT INTO manitodb.tbl_reply (anonymity_yn, board_no, parent_reply_no, register_at, tag_user_no, content, writer, room_user_no, delete_yn, update_yn) VALUES (0, 253, null, '2024-02-16 00:09:50.207168', null, '커피 한잔 하실분~', null, 342, false, null);
INSERT INTO manitodb.tbl_reply (anonymity_yn, board_no, parent_reply_no, register_at, tag_user_no, content, writer, room_user_no, delete_yn, update_yn) VALUES (0, 326, null, '2024-02-16 00:35:51.942016', null, '와 칸쵸! 부럽다', null, 359, false, null);
INSERT INTO manitodb.tbl_reply (anonymity_yn, board_no, parent_reply_no, register_at, tag_user_no, content, writer, room_user_no, delete_yn, update_yn) VALUES (0, 318, null, '2024-02-16 00:35:52.816836', null, '그림 이쁜데요?', null, 360, false, null);
INSERT INTO manitodb.tbl_reply (anonymity_yn, board_no, parent_reply_no, register_at, tag_user_no, content, writer, room_user_no, delete_yn, update_yn) VALUES (0, 318, null, '2024-02-16 00:36:26.625445', null, '찢었다', null, 359, false, null);
INSERT INTO manitodb.tbl_reply (anonymity_yn, board_no, parent_reply_no, register_at, tag_user_no, content, writer, room_user_no, delete_yn, update_yn) VALUES (0, 326, 5, '2024-02-16 00:36:33.763925', null, '저도 먹고싶어요', null, 360, false, null);
INSERT INTO manitodb.tbl_reply (anonymity_yn, board_no, parent_reply_no, register_at, tag_user_no, content, writer, room_user_no, delete_yn, update_yn) VALUES (0, 321, null, '2024-02-16 00:37:19.068995', null, '맛있겠다 누가준거야
', null, 362, false, null);
INSERT INTO manitodb.tbl_reply (anonymity_yn, board_no, parent_reply_no, register_at, tag_user_no, content, writer, room_user_no, delete_yn, update_yn) VALUES (0, 316, null, '2024-02-16 00:37:23.951605', null, '맛잘알', null, 359, false, null);
INSERT INTO manitodb.tbl_reply (anonymity_yn, board_no, parent_reply_no, register_at, tag_user_no, content, writer, room_user_no, delete_yn, update_yn) VALUES (0, 332, null, '2024-02-16 00:37:40.549806', null, 'ㅋㅋㅋㅋ 열심히 쓰시는 모습이 보기 좋습니다', null, 360, false, null);
INSERT INTO manitodb.tbl_reply (anonymity_yn, board_no, parent_reply_no, register_at, tag_user_no, content, writer, room_user_no, delete_yn, update_yn) VALUES (0, 332, null, '2024-02-16 00:37:47.953585', null, '기생충 명작이죠', null, 359, false, null);
INSERT INTO manitodb.tbl_reply (anonymity_yn, board_no, parent_reply_no, register_at, tag_user_no, content, writer, room_user_no, delete_yn, update_yn) VALUES (0, 332, 11, '2024-02-16 00:37:58.434446', null, 'ㅇㅈ합니다', null, 359, false, null);
INSERT INTO manitodb.tbl_reply (anonymity_yn, board_no, parent_reply_no, register_at, tag_user_no, content, writer, room_user_no, delete_yn, update_yn) VALUES (0, 332, null, '2024-02-16 00:38:15.426127', null, '저도 좋아합니다 ㅎㅎ', null, 362, false, null);
INSERT INTO manitodb.tbl_reply (anonymity_yn, board_no, parent_reply_no, register_at, tag_user_no, content, writer, room_user_no, delete_yn, update_yn) VALUES (0, 322, null, '2024-02-16 00:38:21.533932', null, '상당히 귀엽군요', null, 359, false, null);
INSERT INTO manitodb.tbl_reply (anonymity_yn, board_no, parent_reply_no, register_at, tag_user_no, content, writer, room_user_no, delete_yn, update_yn) VALUES (0, 321, null, '2024-02-16 00:39:03.962379', null, '내 마니또 분발해라', null, 359, false, null);
INSERT INTO manitodb.tbl_reply (anonymity_yn, board_no, parent_reply_no, register_at, tag_user_no, content, writer, room_user_no, delete_yn, update_yn) VALUES (0, 321, 9, '2024-02-16 00:39:15.148119', null, '당신 아니야?!', null, 359, false, null);
INSERT INTO manitodb.tbl_reply (anonymity_yn, board_no, parent_reply_no, register_at, tag_user_no, content, writer, room_user_no, delete_yn, update_yn) VALUES (0, 339, null, '2024-02-16 00:40:55.349602', null, '진짜 TTTMIㅋㅋㅋ', null, 359, false, null);
INSERT INTO manitodb.tbl_reply (anonymity_yn, board_no, parent_reply_no, register_at, tag_user_no, content, writer, room_user_no, delete_yn, update_yn) VALUES (0, 332, null, '2024-02-16 00:42:36.705755', null, '저는 기생충입니다.', null, 361, false, null);
