create table tbl_liked
(
    board_no     bigint null,
    liked_no     bigint auto_increment
        primary key,
    room_user_no bigint null,
    constraint FKbvcvjk32jo2dbj1uiiidq34u
        foreign key (room_user_no) references tbl_room_user (room_user_no),
    constraint FKenr6rjh3o8nariaghd1ago5sw
        foreign key (board_no) references tbl_board (board_no)
);

INSERT INTO manitodb.tbl_liked (board_no, room_user_no) VALUES (52, 317);
INSERT INTO manitodb.tbl_liked (board_no, room_user_no) VALUES (52, 321);
INSERT INTO manitodb.tbl_liked (board_no, room_user_no) VALUES (55, 307);
INSERT INTO manitodb.tbl_liked (board_no, room_user_no) VALUES (227, 334);
INSERT INTO manitodb.tbl_liked (board_no, room_user_no) VALUES (260, 341);
INSERT INTO manitodb.tbl_liked (board_no, room_user_no) VALUES (319, 362);
INSERT INTO manitodb.tbl_liked (board_no, room_user_no) VALUES (326, 359);
INSERT INTO manitodb.tbl_liked (board_no, room_user_no) VALUES (318, 360);
INSERT INTO manitodb.tbl_liked (board_no, room_user_no) VALUES (318, 359);
INSERT INTO manitodb.tbl_liked (board_no, room_user_no) VALUES (326, 360);
INSERT INTO manitodb.tbl_liked (board_no, room_user_no) VALUES (321, 362);
INSERT INTO manitodb.tbl_liked (board_no, room_user_no) VALUES (316, 359);
INSERT INTO manitodb.tbl_liked (board_no, room_user_no) VALUES (321, 360);
INSERT INTO manitodb.tbl_liked (board_no, room_user_no) VALUES (332, 360);
INSERT INTO manitodb.tbl_liked (board_no, room_user_no) VALUES (332, 359);
INSERT INTO manitodb.tbl_liked (board_no, room_user_no) VALUES (332, 362);
INSERT INTO manitodb.tbl_liked (board_no, room_user_no) VALUES (322, 359);
INSERT INTO manitodb.tbl_liked (board_no, room_user_no) VALUES (321, 359);
INSERT INTO manitodb.tbl_liked (board_no, room_user_no) VALUES (339, 359);
INSERT INTO manitodb.tbl_liked (board_no, room_user_no) VALUES (318, 362);
