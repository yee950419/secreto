create table tbl_matching
(
    deprecated_at datetime(6) null,
    maniti_no     bigint      null,
    manito_no     bigint      null,
    matching_at   datetime(6) null,
    matching_no   bigint auto_increment
        primary key,
    room_user_no  bigint      null,
    constraint FKs15rjfvwjbdqgl3we25roo5je
        foreign key (room_user_no) references tbl_room_user (room_user_no)
);

INSERT INTO manitodb.tbl_matching (deprecated_at, maniti_no, manito_no, matching_at, room_user_no) VALUES (null, 308, 309, '2024-02-15 21:05:40.617506', 312);
INSERT INTO manitodb.tbl_matching (deprecated_at, maniti_no, manito_no, matching_at, room_user_no) VALUES (null, 310, 312, '2024-02-15 21:05:40.619356', 308);
INSERT INTO manitodb.tbl_matching (deprecated_at, maniti_no, manito_no, matching_at, room_user_no) VALUES (null, 313, 308, '2024-02-15 21:05:40.620729', 310);
INSERT INTO manitodb.tbl_matching (deprecated_at, maniti_no, manito_no, matching_at, room_user_no) VALUES (null, 314, 310, '2024-02-15 21:05:40.622219', 313);
INSERT INTO manitodb.tbl_matching (deprecated_at, maniti_no, manito_no, matching_at, room_user_no) VALUES (null, 307, 313, '2024-02-15 21:05:40.624106', 314);
INSERT INTO manitodb.tbl_matching (deprecated_at, maniti_no, manito_no, matching_at, room_user_no) VALUES (null, 311, 314, '2024-02-15 21:05:40.625510', 307);
INSERT INTO manitodb.tbl_matching (deprecated_at, maniti_no, manito_no, matching_at, room_user_no) VALUES (null, 309, 307, '2024-02-15 21:05:40.627012', 311);
INSERT INTO manitodb.tbl_matching (deprecated_at, maniti_no, manito_no, matching_at, room_user_no) VALUES (null, 312, 311, '2024-02-15 21:05:40.628562', 309);
INSERT INTO manitodb.tbl_matching (deprecated_at, maniti_no, manito_no, matching_at, room_user_no) VALUES (null, 321, 316, '2024-02-15 22:15:07.912044', 318);
INSERT INTO manitodb.tbl_matching (deprecated_at, maniti_no, manito_no, matching_at, room_user_no) VALUES (null, 320, 318, '2024-02-15 22:15:07.913346', 321);
INSERT INTO manitodb.tbl_matching (deprecated_at, maniti_no, manito_no, matching_at, room_user_no) VALUES (null, 319, 321, '2024-02-15 22:15:07.914576', 320);
INSERT INTO manitodb.tbl_matching (deprecated_at, maniti_no, manito_no, matching_at, room_user_no) VALUES (null, 317, 320, '2024-02-15 22:15:07.915830', 319);
INSERT INTO manitodb.tbl_matching (deprecated_at, maniti_no, manito_no, matching_at, room_user_no) VALUES (null, 316, 319, '2024-02-15 22:15:07.918587', 317);
INSERT INTO manitodb.tbl_matching (deprecated_at, maniti_no, manito_no, matching_at, room_user_no) VALUES (null, 318, 317, '2024-02-15 22:15:07.919804', 316);
INSERT INTO manitodb.tbl_matching (deprecated_at, maniti_no, manito_no, matching_at, room_user_no) VALUES (null, 317, 321, '2024-02-15 23:14:54.783826', 320);
INSERT INTO manitodb.tbl_matching (deprecated_at, maniti_no, manito_no, matching_at, room_user_no) VALUES (null, 316, 320, '2024-02-15 23:14:54.783833', 317);
INSERT INTO manitodb.tbl_matching (deprecated_at, maniti_no, manito_no, matching_at, room_user_no) VALUES (null, 321, 317, '2024-02-15 23:20:00.312387', 316);
INSERT INTO manitodb.tbl_matching (deprecated_at, maniti_no, manito_no, matching_at, room_user_no) VALUES (null, 320, 316, '2024-02-15 23:20:00.312391', 321);
INSERT INTO manitodb.tbl_matching (deprecated_at, maniti_no, manito_no, matching_at, room_user_no) VALUES (null, 331, 330, '2024-02-15 23:22:04.049998', 327);
INSERT INTO manitodb.tbl_matching (deprecated_at, maniti_no, manito_no, matching_at, room_user_no) VALUES (null, 332, 327, '2024-02-15 23:22:04.051016', 331);
INSERT INTO manitodb.tbl_matching (deprecated_at, maniti_no, manito_no, matching_at, room_user_no) VALUES (null, 329, 331, '2024-02-15 23:22:04.051983', 332);
INSERT INTO manitodb.tbl_matching (deprecated_at, maniti_no, manito_no, matching_at, room_user_no) VALUES (null, 330, 332, '2024-02-15 23:22:04.052993', 329);
INSERT INTO manitodb.tbl_matching (deprecated_at, maniti_no, manito_no, matching_at, room_user_no) VALUES (null, 327, 329, '2024-02-15 23:22:04.053967', 330);
INSERT INTO manitodb.tbl_matching (deprecated_at, maniti_no, manito_no, matching_at, room_user_no) VALUES (null, 321, 320, '2024-02-15 23:34:49.119523', 317);
INSERT INTO manitodb.tbl_matching (deprecated_at, maniti_no, manito_no, matching_at, room_user_no) VALUES (null, 320, 317, '2024-02-15 23:34:49.119541', 321);
INSERT INTO manitodb.tbl_matching (deprecated_at, maniti_no, manito_no, matching_at, room_user_no) VALUES (null, 339, 338, '2024-02-15 23:42:41.592199', 334);
INSERT INTO manitodb.tbl_matching (deprecated_at, maniti_no, manito_no, matching_at, room_user_no) VALUES (null, 336, 334, '2024-02-15 23:42:41.594224', 339);
INSERT INTO manitodb.tbl_matching (deprecated_at, maniti_no, manito_no, matching_at, room_user_no) VALUES (null, 337, 339, '2024-02-15 23:42:41.596719', 336);
INSERT INTO manitodb.tbl_matching (deprecated_at, maniti_no, manito_no, matching_at, room_user_no) VALUES (null, 338, 336, '2024-02-15 23:42:41.598365', 337);
INSERT INTO manitodb.tbl_matching (deprecated_at, maniti_no, manito_no, matching_at, room_user_no) VALUES (null, 334, 337, '2024-02-15 23:42:41.600025', 338);
INSERT INTO manitodb.tbl_matching (deprecated_at, maniti_no, manito_no, matching_at, room_user_no) VALUES (null, 344, 341, '2024-02-16 00:03:06.906543', 342);
INSERT INTO manitodb.tbl_matching (deprecated_at, maniti_no, manito_no, matching_at, room_user_no) VALUES (null, 345, 342, '2024-02-16 00:03:06.908704', 344);
INSERT INTO manitodb.tbl_matching (deprecated_at, maniti_no, manito_no, matching_at, room_user_no) VALUES (null, 343, 344, '2024-02-16 00:03:06.911855', 345);
INSERT INTO manitodb.tbl_matching (deprecated_at, maniti_no, manito_no, matching_at, room_user_no) VALUES (null, 341, 345, '2024-02-16 00:03:06.913643', 343);
INSERT INTO manitodb.tbl_matching (deprecated_at, maniti_no, manito_no, matching_at, room_user_no) VALUES (null, 342, 343, '2024-02-16 00:03:06.915356', 341);
INSERT INTO manitodb.tbl_matching (deprecated_at, maniti_no, manito_no, matching_at, room_user_no) VALUES (null, 344, 343, '2024-02-16 00:11:52.377493', 341);
INSERT INTO manitodb.tbl_matching (deprecated_at, maniti_no, manito_no, matching_at, room_user_no) VALUES (null, 345, 341, '2024-02-16 00:11:52.377496', 344);
INSERT INTO manitodb.tbl_matching (deprecated_at, maniti_no, manito_no, matching_at, room_user_no) VALUES (null, 345, 343, '2024-02-16 00:12:27.118897', 341);
INSERT INTO manitodb.tbl_matching (deprecated_at, maniti_no, manito_no, matching_at, room_user_no) VALUES (null, 343, 341, '2024-02-16 00:12:27.118905', 345);
INSERT INTO manitodb.tbl_matching (deprecated_at, maniti_no, manito_no, matching_at, room_user_no) VALUES (null, 349, 347, '2024-02-16 00:13:37.162713', 348);
INSERT INTO manitodb.tbl_matching (deprecated_at, maniti_no, manito_no, matching_at, room_user_no) VALUES (null, 351, 348, '2024-02-16 00:13:37.164084', 349);
INSERT INTO manitodb.tbl_matching (deprecated_at, maniti_no, manito_no, matching_at, room_user_no) VALUES (null, 350, 349, '2024-02-16 00:13:37.172271', 351);
INSERT INTO manitodb.tbl_matching (deprecated_at, maniti_no, manito_no, matching_at, room_user_no) VALUES (null, 346, 351, '2024-02-16 00:13:37.174096', 350);
INSERT INTO manitodb.tbl_matching (deprecated_at, maniti_no, manito_no, matching_at, room_user_no) VALUES (null, 347, 350, '2024-02-16 00:13:37.175706', 346);
INSERT INTO manitodb.tbl_matching (deprecated_at, maniti_no, manito_no, matching_at, room_user_no) VALUES (null, 348, 346, '2024-02-16 00:13:37.177306', 347);
INSERT INTO manitodb.tbl_matching (deprecated_at, maniti_no, manito_no, matching_at, room_user_no) VALUES (null, 351, 347, '2024-02-16 00:23:28.084741', 348);
INSERT INTO manitodb.tbl_matching (deprecated_at, maniti_no, manito_no, matching_at, room_user_no) VALUES (null, 350, 348, '2024-02-16 00:23:28.084751', 351);
INSERT INTO manitodb.tbl_matching (deprecated_at, maniti_no, manito_no, matching_at, room_user_no) VALUES (null, 348, 350, '2024-02-16 00:23:32.388102', 346);
INSERT INTO manitodb.tbl_matching (deprecated_at, maniti_no, manito_no, matching_at, room_user_no) VALUES (null, 351, 346, '2024-02-16 00:23:32.388111', 348);
INSERT INTO manitodb.tbl_matching (deprecated_at, maniti_no, manito_no, matching_at, room_user_no) VALUES (null, 341, 341, '2024-02-16 00:23:34.217826', 345);
INSERT INTO manitodb.tbl_matching (deprecated_at, maniti_no, manito_no, matching_at, room_user_no) VALUES (null, 345, 345, '2024-02-16 00:23:34.217837', 341);
INSERT INTO manitodb.tbl_matching (deprecated_at, maniti_no, manito_no, matching_at, room_user_no) VALUES (null, 351, 350, '2024-02-16 00:23:35.600602', 346);
INSERT INTO manitodb.tbl_matching (deprecated_at, maniti_no, manito_no, matching_at, room_user_no) VALUES (null, 350, 346, '2024-02-16 00:23:35.600611', 351);
INSERT INTO manitodb.tbl_matching (deprecated_at, maniti_no, manito_no, matching_at, room_user_no) VALUES (null, 317, 317, '2024-02-16 00:23:36.004238', 321);
INSERT INTO manitodb.tbl_matching (deprecated_at, maniti_no, manito_no, matching_at, room_user_no) VALUES (null, 321, 321, '2024-02-16 00:23:36.004249', 317);
INSERT INTO manitodb.tbl_matching (deprecated_at, maniti_no, manito_no, matching_at, room_user_no) VALUES (null, 321, 321, '2024-02-16 00:23:39.071499', 321);
INSERT INTO manitodb.tbl_matching (deprecated_at, maniti_no, manito_no, matching_at, room_user_no) VALUES (null, 321, 321, '2024-02-16 00:23:39.071509', 321);
INSERT INTO manitodb.tbl_matching (deprecated_at, maniti_no, manito_no, matching_at, room_user_no) VALUES (null, 356, 355, '2024-02-16 00:24:14.600328', 353);
INSERT INTO manitodb.tbl_matching (deprecated_at, maniti_no, manito_no, matching_at, room_user_no) VALUES (null, 354, 353, '2024-02-16 00:24:14.613664', 356);
INSERT INTO manitodb.tbl_matching (deprecated_at, maniti_no, manito_no, matching_at, room_user_no) VALUES (null, 352, 356, '2024-02-16 00:24:14.615755', 354);
INSERT INTO manitodb.tbl_matching (deprecated_at, maniti_no, manito_no, matching_at, room_user_no) VALUES (null, 357, 354, '2024-02-16 00:24:14.620373', 352);
INSERT INTO manitodb.tbl_matching (deprecated_at, maniti_no, manito_no, matching_at, room_user_no) VALUES (null, 355, 352, '2024-02-16 00:24:14.632094', 357);
INSERT INTO manitodb.tbl_matching (deprecated_at, maniti_no, manito_no, matching_at, room_user_no) VALUES (null, 353, 357, '2024-02-16 00:24:14.633562', 355);
INSERT INTO manitodb.tbl_matching (deprecated_at, maniti_no, manito_no, matching_at, room_user_no) VALUES (null, 321, 321, '2024-02-16 00:26:43.756227', 321);
INSERT INTO manitodb.tbl_matching (deprecated_at, maniti_no, manito_no, matching_at, room_user_no) VALUES (null, 321, 321, '2024-02-16 00:26:43.756234', 321);
INSERT INTO manitodb.tbl_matching (deprecated_at, maniti_no, manito_no, matching_at, room_user_no) VALUES (null, 345, 345, '2024-02-16 00:26:48.519761', 345);
INSERT INTO manitodb.tbl_matching (deprecated_at, maniti_no, manito_no, matching_at, room_user_no) VALUES (null, 345, 345, '2024-02-16 00:26:48.519770', 345);
INSERT INTO manitodb.tbl_matching (deprecated_at, maniti_no, manito_no, matching_at, room_user_no) VALUES (null, 350, 350, '2024-02-16 00:26:50.471991', 346);
INSERT INTO manitodb.tbl_matching (deprecated_at, maniti_no, manito_no, matching_at, room_user_no) VALUES (null, 346, 346, '2024-02-16 00:26:50.471998', 350);
INSERT INTO manitodb.tbl_matching (deprecated_at, maniti_no, manito_no, matching_at, room_user_no) VALUES (null, 359, 360, '2024-02-16 00:28:17.048668', 363);
INSERT INTO manitodb.tbl_matching (deprecated_at, maniti_no, manito_no, matching_at, room_user_no) VALUES (null, 362, 363, '2024-02-16 00:28:17.049630', 359);
INSERT INTO manitodb.tbl_matching (deprecated_at, maniti_no, manito_no, matching_at, room_user_no) VALUES (null, 358, 359, '2024-02-16 00:28:17.050605', 362);
INSERT INTO manitodb.tbl_matching (deprecated_at, maniti_no, manito_no, matching_at, room_user_no) VALUES (null, 361, 362, '2024-02-16 00:28:17.051521', 358);
INSERT INTO manitodb.tbl_matching (deprecated_at, maniti_no, manito_no, matching_at, room_user_no) VALUES (null, 360, 358, '2024-02-16 00:28:17.052401', 361);
INSERT INTO manitodb.tbl_matching (deprecated_at, maniti_no, manito_no, matching_at, room_user_no) VALUES (null, 363, 361, '2024-02-16 00:28:17.053278', 360);
INSERT INTO manitodb.tbl_matching (deprecated_at, maniti_no, manito_no, matching_at, room_user_no) VALUES (null, 350, 350, '2024-02-16 00:46:05.648374', 350);
INSERT INTO manitodb.tbl_matching (deprecated_at, maniti_no, manito_no, matching_at, room_user_no) VALUES (null, 350, 350, '2024-02-16 00:46:05.648379', 350);
INSERT INTO manitodb.tbl_matching (deprecated_at, maniti_no, manito_no, matching_at, room_user_no) VALUES (null, 365, 367, '2024-02-16 00:53:10.657371', 366);
INSERT INTO manitodb.tbl_matching (deprecated_at, maniti_no, manito_no, matching_at, room_user_no) VALUES (null, 368, 366, '2024-02-16 00:53:10.658311', 365);
INSERT INTO manitodb.tbl_matching (deprecated_at, maniti_no, manito_no, matching_at, room_user_no) VALUES (null, 335, 365, '2024-02-16 00:53:10.659238', 368);
INSERT INTO manitodb.tbl_matching (deprecated_at, maniti_no, manito_no, matching_at, room_user_no) VALUES (null, 367, 368, '2024-02-16 00:53:10.660228', 335);
INSERT INTO manitodb.tbl_matching (deprecated_at, maniti_no, manito_no, matching_at, room_user_no) VALUES (null, 366, 335, '2024-02-16 00:53:10.661098', 367);
INSERT INTO manitodb.tbl_matching (deprecated_at, maniti_no, manito_no, matching_at, room_user_no) VALUES (null, 373, 369, '2024-02-16 01:10:14.129364', 372);
INSERT INTO manitodb.tbl_matching (deprecated_at, maniti_no, manito_no, matching_at, room_user_no) VALUES (null, 371, 372, '2024-02-16 01:10:14.130244', 373);
INSERT INTO manitodb.tbl_matching (deprecated_at, maniti_no, manito_no, matching_at, room_user_no) VALUES (null, 370, 373, '2024-02-16 01:10:14.131110', 371);
INSERT INTO manitodb.tbl_matching (deprecated_at, maniti_no, manito_no, matching_at, room_user_no) VALUES (null, 369, 371, '2024-02-16 01:10:14.131963', 370);
INSERT INTO manitodb.tbl_matching (deprecated_at, maniti_no, manito_no, matching_at, room_user_no) VALUES (null, 372, 370, '2024-02-16 01:10:14.132830', 369);
