create table tbl_group_chat_message
(
    group_chat_message_no bigint auto_increment
        primary key,
    group_chat_no         bigint       null,
    message               text         null,
    send_at               datetime(6)  null,
    sender                varchar(255) null,
    constraint FK1chi8y3ycdsxkdjj3llny77uj
        foreign key (group_chat_no) references tbl_group_chat (group_chat_no)
);

