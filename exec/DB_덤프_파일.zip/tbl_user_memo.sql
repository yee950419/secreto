create table tbl_user_memo
(
    memo_to             bigint                        null,
    room_user_no        bigint                        null,
    user_memo_no        bigint auto_increment
        primary key,
    memo                text                          null,
    manito_predict_type enum ('YES', 'NO', 'UNKNOWN') not null,
    constraint FKfepwvdsrqpl5o36gir6fc3ch9
        foreign key (room_user_no) references tbl_room_user (room_user_no)
);

INSERT INTO manitodb.tbl_user_memo (memo_to, room_user_no, memo, manito_predict_type) VALUES (316, 321, '관상이 마니또상임', 'YES');
INSERT INTO manitodb.tbl_user_memo (memo_to, room_user_no, memo, manito_predict_type) VALUES (314, 307, '당신이 마니또야', 'YES');
INSERT INTO manitodb.tbl_user_memo (memo_to, room_user_no, memo, manito_predict_type) VALUES (319, 316, '', 'UNKNOWN');
INSERT INTO manitodb.tbl_user_memo (memo_to, room_user_no, memo, manito_predict_type) VALUES (317, 316, '', 'YES');
INSERT INTO manitodb.tbl_user_memo (memo_to, room_user_no, memo, manito_predict_type) VALUES (320, 316, '', 'NO');
INSERT INTO manitodb.tbl_user_memo (memo_to, room_user_no, memo, manito_predict_type) VALUES (321, 316, '', 'UNKNOWN');
INSERT INTO manitodb.tbl_user_memo (memo_to, room_user_no, memo, manito_predict_type) VALUES (332, 330, '', 'YES');
INSERT INTO manitodb.tbl_user_memo (memo_to, room_user_no, memo, manito_predict_type) VALUES (330, 331, 'ㅋㅋ', 'YES');
INSERT INTO manitodb.tbl_user_memo (memo_to, room_user_no, memo, manito_predict_type) VALUES (329, 327, '마니또?', 'YES');
INSERT INTO manitodb.tbl_user_memo (memo_to, room_user_no, memo, manito_predict_type) VALUES (329, 331, 'ㄹㄹ', 'NO');
INSERT INTO manitodb.tbl_user_memo (memo_to, room_user_no, memo, manito_predict_type) VALUES (327, 331, 'ㅇㄹ', 'UNKNOWN');
INSERT INTO manitodb.tbl_user_memo (memo_to, room_user_no, memo, manito_predict_type) VALUES (333, 339, '잘생겨서 ㅎㅎ', 'YES');
INSERT INTO manitodb.tbl_user_memo (memo_to, room_user_no, memo, manito_predict_type) VALUES (334, 333, '마니또!', 'YES');
INSERT INTO manitodb.tbl_user_memo (memo_to, room_user_no, memo, manito_predict_type) VALUES (343, 342, '너가 내 마니또같애', 'YES');
INSERT INTO manitodb.tbl_user_memo (memo_to, room_user_no, memo, manito_predict_type) VALUES (343, 340, '', 'YES');
INSERT INTO manitodb.tbl_user_memo (memo_to, room_user_no, memo, manito_predict_type) VALUES (345, 342, '넌 아닌거같애', 'NO');
INSERT INTO manitodb.tbl_user_memo (memo_to, room_user_no, memo, manito_predict_type) VALUES (344, 345, '너가 범인이지?', 'YES');
INSERT INTO manitodb.tbl_user_memo (memo_to, room_user_no, memo, manito_predict_type) VALUES (341, 345, '너는 일단 아닌거같아
', 'NO');
INSERT INTO manitodb.tbl_user_memo (memo_to, room_user_no, memo, manito_predict_type) VALUES (341, 342, '얜 잘 모르겠다', 'UNKNOWN');
INSERT INTO manitodb.tbl_user_memo (memo_to, room_user_no, memo, manito_predict_type) VALUES (342, 345, '당신은 아니야', 'NO');
INSERT INTO manitodb.tbl_user_memo (memo_to, room_user_no, memo, manito_predict_type) VALUES (340, 342, 'XXX', 'NO');
INSERT INTO manitodb.tbl_user_memo (memo_to, room_user_no, memo, manito_predict_type) VALUES (350, 348, '당신은 나의 마니또가 아니야', 'NO');
INSERT INTO manitodb.tbl_user_memo (memo_to, room_user_no, memo, manito_predict_type) VALUES (348, 351, '', 'YES');
INSERT INTO manitodb.tbl_user_memo (memo_to, room_user_no, memo, manito_predict_type) VALUES (351, 348, '당신은 나의 마니또가 아니야', 'NO');
INSERT INTO manitodb.tbl_user_memo (memo_to, room_user_no, memo, manito_predict_type) VALUES (347, 348, '상학이형이 내 마니또지??', 'YES');
INSERT INTO manitodb.tbl_user_memo (memo_to, room_user_no, memo, manito_predict_type) VALUES (347, 349, '일 잘하게 생김', 'YES');
INSERT INTO manitodb.tbl_user_memo (memo_to, room_user_no, memo, manito_predict_type) VALUES (360, 358, '', 'UNKNOWN');
INSERT INTO manitodb.tbl_user_memo (memo_to, room_user_no, memo, manito_predict_type) VALUES (358, 361, '잘생겨서 ㅎㅎ', 'YES');
INSERT INTO manitodb.tbl_user_memo (memo_to, room_user_no, memo, manito_predict_type) VALUES (360, 362, '너가 내 마니또아니냐??', 'YES');
INSERT INTO manitodb.tbl_user_memo (memo_to, room_user_no, memo, manito_predict_type) VALUES (360, 363, '마니또인듯', 'YES');
INSERT INTO manitodb.tbl_user_memo (memo_to, room_user_no, memo, manito_predict_type) VALUES (361, 360, '숭구리당당 숭당당~', 'NO');
INSERT INTO manitodb.tbl_user_memo (memo_to, room_user_no, memo, manito_predict_type) VALUES (361, 359, '관상이 마니또상임', 'YES');
INSERT INTO manitodb.tbl_user_memo (memo_to, room_user_no, memo, manito_predict_type) VALUES (362, 360, '이사람임', 'YES');
INSERT INTO manitodb.tbl_user_memo (memo_to, room_user_no, memo, manito_predict_type) VALUES (362, 358, '마니또인 것 같음...', 'YES');
INSERT INTO manitodb.tbl_user_memo (memo_to, room_user_no, memo, manito_predict_type) VALUES (363, 358, '', 'UNKNOWN');
INSERT INTO manitodb.tbl_user_memo (memo_to, room_user_no, memo, manito_predict_type) VALUES (359, 358, '', 'NO');
INSERT INTO manitodb.tbl_user_memo (memo_to, room_user_no, memo, manito_predict_type) VALUES (361, 363, '아닌것 같다', 'UNKNOWN');
INSERT INTO manitodb.tbl_user_memo (memo_to, room_user_no, memo, manito_predict_type) VALUES (362, 363, '절대 아님', 'NO');
INSERT INTO manitodb.tbl_user_memo (memo_to, room_user_no, memo, manito_predict_type) VALUES (335, 365, 'ㅋㅋㅋㅋㅋ', 'YES');
INSERT INTO manitodb.tbl_user_memo (memo_to, room_user_no, memo, manito_predict_type) VALUES (365, 335, '고구마 당신이 내 마니또야!', 'YES');
INSERT INTO manitodb.tbl_user_memo (memo_to, room_user_no, memo, manito_predict_type) VALUES (368, 335, '', 'NO');
INSERT INTO manitodb.tbl_user_memo (memo_to, room_user_no, memo, manito_predict_type) VALUES (370, 372, '헬로우월드', 'YES');
INSERT INTO manitodb.tbl_user_memo (memo_to, room_user_no, memo, manito_predict_type) VALUES (370, 369, '마니또다!', 'YES');
INSERT INTO manitodb.tbl_user_memo (memo_to, room_user_no, memo, manito_predict_type) VALUES (371, 369, '', 'UNKNOWN');
INSERT INTO manitodb.tbl_user_memo (memo_to, room_user_no, memo, manito_predict_type) VALUES (373, 369, '', 'NO');
