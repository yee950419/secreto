create table tbl_word_cloud
(
    id           bigint auto_increment
        primary key,
    room_user_no bigint       null,
    content      varchar(255) null,
    value        bigint       null,
    constraint tbl_word_cloud_ibfk_1
        foreign key (room_user_no) references tbl_room_user (room_user_no)
);

create index room_user_no
    on tbl_word_cloud (room_user_no);

INSERT INTO manitodb.tbl_word_cloud (room_user_no, content, value) VALUES (327, '워드클라우드', 1);
INSERT INTO manitodb.tbl_word_cloud (room_user_no, content, value) VALUES (331, 'ㅎㅇㅎㅇ', 3);
INSERT INTO manitodb.tbl_word_cloud (room_user_no, content, value) VALUES (327, '당신만의 비밀친구', 1);
INSERT INTO manitodb.tbl_word_cloud (room_user_no, content, value) VALUES (327, '시크리또', 5);
INSERT INTO manitodb.tbl_word_cloud (room_user_no, content, value) VALUES (329, 'ㅋ', 1);
INSERT INTO manitodb.tbl_word_cloud (room_user_no, content, value) VALUES (329, '헬로', 1);
INSERT INTO manitodb.tbl_word_cloud (room_user_no, content, value) VALUES (331, '발표 되나?', 1);
INSERT INTO manitodb.tbl_word_cloud (room_user_no, content, value) VALUES (336, 'ㅎㅎ', 1);
INSERT INTO manitodb.tbl_word_cloud (room_user_no, content, value) VALUES (336, '하이하이', 1);
INSERT INTO manitodb.tbl_word_cloud (room_user_no, content, value) VALUES (336, 'ㅎㅇ', 1);
INSERT INTO manitodb.tbl_word_cloud (room_user_no, content, value) VALUES (334, '하하하', 2);
INSERT INTO manitodb.tbl_word_cloud (room_user_no, content, value) VALUES (334, '화이팅', 1);
INSERT INTO manitodb.tbl_word_cloud (room_user_no, content, value) VALUES (334, '화팅', 1);
INSERT INTO manitodb.tbl_word_cloud (room_user_no, content, value) VALUES (334, '키키키키키', 1);
INSERT INTO manitodb.tbl_word_cloud (room_user_no, content, value) VALUES (334, '키키키', 1);
INSERT INTO manitodb.tbl_word_cloud (room_user_no, content, value) VALUES (338, '와우', 1);
INSERT INTO manitodb.tbl_word_cloud (room_user_no, content, value) VALUES (338, '실시간', 1);
INSERT INTO manitodb.tbl_word_cloud (room_user_no, content, value) VALUES (335, '워드 클라우드', 1);
INSERT INTO manitodb.tbl_word_cloud (room_user_no, content, value) VALUES (365, 'A805', 2);
INSERT INTO manitodb.tbl_word_cloud (room_user_no, content, value) VALUES (366, 'ㅋㅋ', 2);
INSERT INTO manitodb.tbl_word_cloud (room_user_no, content, value) VALUES (365, '김현창', 1);
INSERT INTO manitodb.tbl_word_cloud (room_user_no, content, value) VALUES (365, '지인성', 1);
INSERT INTO manitodb.tbl_word_cloud (room_user_no, content, value) VALUES (335, '당신의 비밀친구 시크리또', 2);
INSERT INTO manitodb.tbl_word_cloud (room_user_no, content, value) VALUES (365, '이상학', 2);
INSERT INTO manitodb.tbl_word_cloud (room_user_no, content, value) VALUES (366, '발표 잘하네~', 1);
INSERT INTO manitodb.tbl_word_cloud (room_user_no, content, value) VALUES (365, '조승우', 1);
INSERT INTO manitodb.tbl_word_cloud (room_user_no, content, value) VALUES (365, '이민지', 1);
INSERT INTO manitodb.tbl_word_cloud (room_user_no, content, value) VALUES (366, '이상학 누구야', 1);
INSERT INTO manitodb.tbl_word_cloud (room_user_no, content, value) VALUES (365, '신시원', 1);
INSERT INTO manitodb.tbl_word_cloud (room_user_no, content, value) VALUES (369, '당신의', 1);
INSERT INTO manitodb.tbl_word_cloud (room_user_no, content, value) VALUES (372, '안녕하세요', 1);
INSERT INTO manitodb.tbl_word_cloud (room_user_no, content, value) VALUES (370, '재밌어요', 1);
INSERT INTO manitodb.tbl_word_cloud (room_user_no, content, value) VALUES (369, '비밀친구', 1);
INSERT INTO manitodb.tbl_word_cloud (room_user_no, content, value) VALUES (372, 'ㅋㅋㅋ', 2);
INSERT INTO manitodb.tbl_word_cloud (room_user_no, content, value) VALUES (371, 'ㅎㅎㅎ\'', 1);
INSERT INTO manitodb.tbl_word_cloud (room_user_no, content, value) VALUES (371, 'ㅎㅇ히ㅏㅓㄴㅇㄹ', 1);
INSERT INTO manitodb.tbl_word_cloud (room_user_no, content, value) VALUES (369, 'ㅁㄴㅇㄹ', 1);
INSERT INTO manitodb.tbl_word_cloud (room_user_no, content, value) VALUES (369, 'Hi', 1);
INSERT INTO manitodb.tbl_word_cloud (room_user_no, content, value) VALUES (369, 'zzz', 1);
INSERT INTO manitodb.tbl_word_cloud (room_user_no, content, value) VALUES (369, 'Good!', 1);
INSERT INTO manitodb.tbl_word_cloud (room_user_no, content, value) VALUES (369, 'Secreto', 1);
INSERT INTO manitodb.tbl_word_cloud (room_user_no, content, value) VALUES (361, '안녕하세요!', 1);
INSERT INTO manitodb.tbl_word_cloud (room_user_no, content, value) VALUES (361, '반갑습니다!', 1);
