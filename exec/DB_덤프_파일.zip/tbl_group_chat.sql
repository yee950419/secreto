create table tbl_group_chat
(
    group_chat_no bigint auto_increment
        primary key,
    room_user_no  bigint null,
    constraint FKknjqjwtei5ief98tqq0blaged
        foreign key (room_user_no) references tbl_room_user (room_user_no)
);

