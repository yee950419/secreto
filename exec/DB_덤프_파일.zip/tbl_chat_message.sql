create table tbl_chat_message
(
    read_yn         bit          not null,
    chat_message_no bigint auto_increment
        primary key,
    chat_no         bigint       null,
    message         text         null,
    send_at         datetime(6)  null,
    sender          varchar(255) null,
    sender_id       mediumtext   null,
    constraint FKn5dh8n5brkswoc2w1aylir221
        foreign key (chat_no) references tbl_chat (chat_no)
);

INSERT INTO manitodb.tbl_chat_message (read_yn, chat_no, message, send_at, sender, sender_id) VALUES (false, 15, '민트나라초코공주', '2024-02-15 22:25:17.769127', '고영이', '321');
INSERT INTO manitodb.tbl_chat_message (read_yn, chat_no, message, send_at, sender, sender_id) VALUES (false, 10, '안녕하세요^^', '2024-02-15 22:26:25.389460', '고영이', '321');
INSERT INTO manitodb.tbl_chat_message (read_yn, chat_no, message, send_at, sender, sender_id) VALUES (false, 14, '반가워요!', '2024-02-15 22:43:57.716797', '민초나라', '320');
INSERT INTO manitodb.tbl_chat_message (read_yn, chat_no, message, send_at, sender, sender_id) VALUES (false, 10, 'ㅎㅇㅎㅇ영', '2024-02-15 22:44:37.770942', '서울_8반_이상학', '319');
INSERT INTO manitodb.tbl_chat_message (read_yn, chat_no, message, send_at, sender, sender_id) VALUES (false, 11, '123', '2024-02-15 23:10:07.642001', '시원', '316');
INSERT INTO manitodb.tbl_chat_message (read_yn, chat_no, message, send_at, sender, sender_id) VALUES (false, 13, 'ㅎㅇㅎㅇ', '2024-02-15 23:10:50.606711', '시원', '316');
INSERT INTO manitodb.tbl_chat_message (read_yn, chat_no, message, send_at, sender, sender_id) VALUES (false, 11, '안녕하세요', '2024-02-15 23:11:32.072835', '고구마', '317');
INSERT INTO manitodb.tbl_chat_message (read_yn, chat_no, message, send_at, sender, sender_id) VALUES (false, 10, '안녕하세요', '2024-02-15 23:11:50.444484', '시원', '316');
INSERT INTO manitodb.tbl_chat_message (read_yn, chat_no, message, send_at, sender, sender_id) VALUES (false, 10, 'test', '2024-02-15 23:11:51.546269', '고영이', '321');
INSERT INTO manitodb.tbl_chat_message (read_yn, chat_no, message, send_at, sender, sender_id) VALUES (false, 10, '안녕하세요 고구마입니다', '2024-02-15 23:11:52.624926', '고구마', '317');
INSERT INTO manitodb.tbl_chat_message (read_yn, chat_no, message, send_at, sender, sender_id) VALUES (false, 10, '흥칫뿡', '2024-02-15 23:11:53.622445', '민초나라', '320');
INSERT INTO manitodb.tbl_chat_message (read_yn, chat_no, message, send_at, sender, sender_id) VALUES (false, 10, 'gg', '2024-02-15 23:11:59.029222', '서울_8반_이상학', '319');
INSERT INTO manitodb.tbl_chat_message (read_yn, chat_no, message, send_at, sender, sender_id) VALUES (false, 11, '당신 누구야', '2024-02-15 23:14:10.380704', '시원', '316');
INSERT INTO manitodb.tbl_chat_message (read_yn, chat_no, message, send_at, sender, sender_id) VALUES (false, 18, 'ㅎㅇ', '2024-02-15 23:23:44.018796', '이민지2', '330');
INSERT INTO manitodb.tbl_chat_message (read_yn, chat_no, message, send_at, sender, sender_id) VALUES (false, 17, '안녕하세요', '2024-02-15 23:23:49.442521', '고구마', '329');
INSERT INTO manitodb.tbl_chat_message (read_yn, chat_no, message, send_at, sender, sender_id) VALUES (false, 18, '당신 누구야', '2024-02-15 23:23:52.059996', '신시원', '327');
INSERT INTO manitodb.tbl_chat_message (read_yn, chat_no, message, send_at, sender, sender_id) VALUES (false, 18, '누구게', '2024-02-15 23:23:55.483918', '이민지2', '330');
INSERT INTO manitodb.tbl_chat_message (read_yn, chat_no, message, send_at, sender, sender_id) VALUES (false, 17, '저는 고구마입니다', '2024-02-15 23:23:58.650515', '고구마', '329');
INSERT INTO manitodb.tbl_chat_message (read_yn, chat_no, message, send_at, sender, sender_id) VALUES (false, 17, 'ㅎㅇㅎㅇ', '2024-02-15 23:24:00.149136', '서울_8반_이상학', '331');
INSERT INTO manitodb.tbl_chat_message (read_yn, chat_no, message, send_at, sender, sender_id) VALUES (false, 19, '안녕', '2024-02-15 23:24:04.487892', '고구마', '329');
INSERT INTO manitodb.tbl_chat_message (read_yn, chat_no, message, send_at, sender, sender_id) VALUES (false, 17, '반가워요', '2024-02-15 23:24:04.654566', '신시원', '327');
INSERT INTO manitodb.tbl_chat_message (read_yn, chat_no, message, send_at, sender, sender_id) VALUES (false, 17, 'ㅎㅇ', '2024-02-15 23:24:06.333461', '이민지2', '330');
INSERT INTO manitodb.tbl_chat_message (read_yn, chat_no, message, send_at, sender, sender_id) VALUES (false, 17, '발표 화이팅', '2024-02-15 23:24:07.850170', '서울_8반_이상학', '331');
INSERT INTO manitodb.tbl_chat_message (read_yn, chat_no, message, send_at, sender, sender_id) VALUES (false, 17, 'a805', '2024-02-15 23:24:11.370575', '고구마', '329');
INSERT INTO manitodb.tbl_chat_message (read_yn, chat_no, message, send_at, sender, sender_id) VALUES (false, 17, '수고링', '2024-02-15 23:24:21.417941', '이민지2', '330');
INSERT INTO manitodb.tbl_chat_message (read_yn, chat_no, message, send_at, sender, sender_id) VALUES (false, 23, '1빠', '2024-02-15 23:44:38.744027', '야옹이', '337');
INSERT INTO manitodb.tbl_chat_message (read_yn, chat_no, message, send_at, sender, sender_id) VALUES (false, 23, 'ㅎㅇㅎㅇ용', '2024-02-15 23:44:39.166863', '서울_8반_이상학', '336');
INSERT INTO manitodb.tbl_chat_message (read_yn, chat_no, message, send_at, sender, sender_id) VALUES (false, 23, '방가방가', '2024-02-15 23:44:46.759627', '승구리당당', '339');
INSERT INTO manitodb.tbl_chat_message (read_yn, chat_no, message, send_at, sender, sender_id) VALUES (false, 23, '방장 어디갓오', '2024-02-15 23:44:48.182146', '야옹이', '337');
INSERT INTO manitodb.tbl_chat_message (read_yn, chat_no, message, send_at, sender, sender_id) VALUES (false, 23, '안녕하세요', '2024-02-15 23:44:50.165688', '고구마', '334');
INSERT INTO manitodb.tbl_chat_message (read_yn, chat_no, message, send_at, sender, sender_id) VALUES (false, 49, '안녕하세요 민나상~', '2024-02-16 00:31:44.409874', '숭구리당당', '361');
INSERT INTO manitodb.tbl_chat_message (read_yn, chat_no, message, send_at, sender, sender_id) VALUES (false, 49, '안녕', '2024-02-16 00:31:51.181507', '망고아빠', '363');
INSERT INTO manitodb.tbl_chat_message (read_yn, chat_no, message, send_at, sender, sender_id) VALUES (false, 49, '안녕하세요', '2024-02-16 00:31:54.832481', '고구마', '362');
INSERT INTO manitodb.tbl_chat_message (read_yn, chat_no, message, send_at, sender, sender_id) VALUES (false, 49, 'ㅎㅇ', '2024-02-16 00:31:54.865116', '서울_8반_이상학', '360');
INSERT INTO manitodb.tbl_chat_message (read_yn, chat_no, message, send_at, sender, sender_id) VALUES (false, 49, '방가방가', '2024-02-16 00:31:55.291542', '고영이', '359');
INSERT INTO manitodb.tbl_chat_message (read_yn, chat_no, message, send_at, sender, sender_id) VALUES (false, 49, '고구마입니다', '2024-02-16 00:31:56.035373', '고구마', '362');
INSERT INTO manitodb.tbl_chat_message (read_yn, chat_no, message, send_at, sender, sender_id) VALUES (false, 53, '누구야 마니또님', '2024-02-16 00:31:58.242091', '숭구리당당', '361');
INSERT INTO manitodb.tbl_chat_message (read_yn, chat_no, message, send_at, sender, sender_id) VALUES (false, 49, '고영이입니다', '2024-02-16 00:31:59.430598', '고영이', '359');
INSERT INTO manitodb.tbl_chat_message (read_yn, chat_no, message, send_at, sender, sender_id) VALUES (false, 49, 'ㅎㅎㅎㅎㅎㅎㅎ', '2024-02-16 00:31:59.535200', '고구마', '362');
INSERT INTO manitodb.tbl_chat_message (read_yn, chat_no, message, send_at, sender, sender_id) VALUES (false, 49, '생각보다 빠른데?', '2024-02-16 00:32:00.120013', '서울_8반_이상학', '360');
INSERT INTO manitodb.tbl_chat_message (read_yn, chat_no, message, send_at, sender, sender_id) VALUES (false, 53, '님 존경함니다.', '2024-02-16 00:32:01.726179', '숭구리당당', '361');
INSERT INTO manitodb.tbl_chat_message (read_yn, chat_no, message, send_at, sender, sender_id) VALUES (false, 49, '안녕하세요', '2024-02-16 00:32:02.012094', '신시원', '358');
INSERT INTO manitodb.tbl_chat_message (read_yn, chat_no, message, send_at, sender, sender_id) VALUES (false, 49, 'ㄹㅇ', '2024-02-16 00:32:02.364382', '고구마', '362');
INSERT INTO manitodb.tbl_chat_message (read_yn, chat_no, message, send_at, sender, sender_id) VALUES (false, 49, '카톡 게섯거라', '2024-02-16 00:32:08.270448', '고영이', '359');
INSERT INTO manitodb.tbl_chat_message (read_yn, chat_no, message, send_at, sender, sender_id) VALUES (false, 49, '서버 튼튼하네', '2024-02-16 00:32:10.350298', '망고아빠', '363');
INSERT INTO manitodb.tbl_chat_message (read_yn, chat_no, message, send_at, sender, sender_id) VALUES (false, 49, 'ㄹㅇ 나쁘지 않은듯', '2024-02-16 00:32:10.847456', '숭구리당당', '361');
INSERT INTO manitodb.tbl_chat_message (read_yn, chat_no, message, send_at, sender, sender_id) VALUES (false, 50, '당신 누구야', '2024-02-16 00:32:12.500780', '신시원', '358');
INSERT INTO manitodb.tbl_chat_message (read_yn, chat_no, message, send_at, sender, sender_id) VALUES (false, 53, '안녕하세요', '2024-02-16 00:32:18.406852', '신시원', '358');
INSERT INTO manitodb.tbl_chat_message (read_yn, chat_no, message, send_at, sender, sender_id) VALUES (false, 53, '당신의 비밀친구', '2024-02-16 00:32:22.413665', '신시원', '358');
INSERT INTO manitodb.tbl_chat_message (read_yn, chat_no, message, send_at, sender, sender_id) VALUES (false, 53, '시크리또', '2024-02-16 00:32:24.139144', '신시원', '358');
INSERT INTO manitodb.tbl_chat_message (read_yn, chat_no, message, send_at, sender, sender_id) VALUES (false, 55, '안녕', '2024-02-16 00:32:25.578637', '망고아빠', '363');
INSERT INTO manitodb.tbl_chat_message (read_yn, chat_no, message, send_at, sender, sender_id) VALUES (false, 52, '내가 누군줄 알아요?', '2024-02-16 00:32:25.869023', '숭구리당당', '361');
INSERT INTO manitodb.tbl_chat_message (read_yn, chat_no, message, send_at, sender, sender_id) VALUES (false, 54, '안녕 구마야', '2024-02-16 00:32:28.973466', '고영이', '359');
INSERT INTO manitodb.tbl_chat_message (read_yn, chat_no, message, send_at, sender, sender_id) VALUES (false, 50, '나', '2024-02-16 00:32:32.391421', '고구마', '362');
INSERT INTO manitodb.tbl_chat_message (read_yn, chat_no, message, send_at, sender, sender_id) VALUES (false, 51, 'ㅎㅇ', '2024-02-16 00:32:34.022317', '고영이', '359');
INSERT INTO manitodb.tbl_chat_message (read_yn, chat_no, message, send_at, sender, sender_id) VALUES (false, 50, '누군지 아시겠어요', '2024-02-16 00:32:36.346580', '고구마', '362');
INSERT INTO manitodb.tbl_chat_message (read_yn, chat_no, message, send_at, sender, sender_id) VALUES (false, 55, '형..', '2024-02-16 00:32:36.917955', '망고아빠', '363');
INSERT INTO manitodb.tbl_chat_message (read_yn, chat_no, message, send_at, sender, sender_id) VALUES (false, 53, '데헷 엣큥~', '2024-02-16 00:32:37.166745', '숭구리당당', '361');
INSERT INTO manitodb.tbl_chat_message (read_yn, chat_no, message, send_at, sender, sender_id) VALUES (false, 50, '??', '2024-02-16 00:32:37.861468', '고구마', '362');
INSERT INTO manitodb.tbl_chat_message (read_yn, chat_no, message, send_at, sender, sender_id) VALUES (false, 50, '민지님', '2024-02-16 00:32:40.004495', '신시원', '358');
INSERT INTO manitodb.tbl_chat_message (read_yn, chat_no, message, send_at, sender, sender_id) VALUES (false, 52, '내가 어떻게 알아 ㅡㅡ', '2024-02-16 00:32:40.808307', '서울_8반_이상학', '360');
INSERT INTO manitodb.tbl_chat_message (read_yn, chat_no, message, send_at, sender, sender_id) VALUES (false, 54, 'who are you', '2024-02-16 00:32:44.149146', '고구마', '362');
INSERT INTO manitodb.tbl_chat_message (read_yn, chat_no, message, send_at, sender, sender_id) VALUES (false, 50, '아닙니다', '2024-02-16 00:32:50.029127', '고구마', '362');
INSERT INTO manitodb.tbl_chat_message (read_yn, chat_no, message, send_at, sender, sender_id) VALUES (false, 49, '캬', '2024-02-16 00:32:50.525167', '신시원', '358');
INSERT INTO manitodb.tbl_chat_message (read_yn, chat_no, message, send_at, sender, sender_id) VALUES (false, 54, 'who i am', '2024-02-16 00:32:54.178227', '고영이', '359');
INSERT INTO manitodb.tbl_chat_message (read_yn, chat_no, message, send_at, sender, sender_id) VALUES (false, 52, '나중에 두고 봅시다 껄껄', '2024-02-16 00:32:54.399116', '숭구리당당', '361');
INSERT INTO manitodb.tbl_chat_message (read_yn, chat_no, message, send_at, sender, sender_id) VALUES (false, 55, 'ㅎㅇㅎㅇ', '2024-02-16 00:32:59.058643', '서울_8반_이상학', '360');
INSERT INTO manitodb.tbl_chat_message (read_yn, chat_no, message, send_at, sender, sender_id) VALUES (false, 51, '외롭다,,', '2024-02-16 00:33:08.432809', '고영이', '359');
INSERT INTO manitodb.tbl_chat_message (read_yn, chat_no, message, send_at, sender, sender_id) VALUES (false, 55, 'ㅎㅇㅎㅇ', '2024-02-16 00:33:09.551678', '서울_8반_이상학', '360');
INSERT INTO manitodb.tbl_chat_message (read_yn, chat_no, message, send_at, sender, sender_id) VALUES (false, 51, 'ㅎㄴ', '2024-02-16 00:33:14.034988', '망고아빠', '363');
INSERT INTO manitodb.tbl_chat_message (read_yn, chat_no, message, send_at, sender, sender_id) VALUES (false, 51, 'ㅎㅇ', '2024-02-16 00:33:16.164512', '망고아빠', '363');
INSERT INTO manitodb.tbl_chat_message (read_yn, chat_no, message, send_at, sender, sender_id) VALUES (false, 51, '고먐미', '2024-02-16 00:33:20.569319', '망고아빠', '363');
INSERT INTO manitodb.tbl_chat_message (read_yn, chat_no, message, send_at, sender, sender_id) VALUES (false, 51, '고양이조아', '2024-02-16 00:33:28.792052', '고영이', '359');
INSERT INTO manitodb.tbl_chat_message (read_yn, chat_no, message, send_at, sender, sender_id) VALUES (false, 55, '인성아', '2024-02-16 00:35:05.537316', '서울_8반_이상학', '360');
INSERT INTO manitodb.tbl_chat_message (read_yn, chat_no, message, send_at, sender, sender_id) VALUES (false, 55, '빨간거 나오나', '2024-02-16 00:35:08.364633', '서울_8반_이상학', '360');
INSERT INTO manitodb.tbl_chat_message (read_yn, chat_no, message, send_at, sender, sender_id) VALUES (false, 55, '나옴???', '2024-02-16 00:35:11.408908', '서울_8반_이상학', '360');
INSERT INTO manitodb.tbl_chat_message (read_yn, chat_no, message, send_at, sender, sender_id) VALUES (false, 56, 'ㅎㅇㅎㅇ', '2024-02-16 00:55:40.434992', '이상학', '366');
INSERT INTO manitodb.tbl_chat_message (read_yn, chat_no, message, send_at, sender, sender_id) VALUES (false, 60, '안녕 나의 마니띠', '2024-02-16 00:55:41.169710', '신시원', '335');
INSERT INTO manitodb.tbl_chat_message (read_yn, chat_no, message, send_at, sender, sender_id) VALUES (false, 60, 'ㅎㅇ', '2024-02-16 00:55:43.178234', '고영이', '367');
INSERT INTO manitodb.tbl_chat_message (read_yn, chat_no, message, send_at, sender, sender_id) VALUES (false, 56, '안녕하십니까', '2024-02-16 00:55:45.231190', '김현창', '365');
INSERT INTO manitodb.tbl_chat_message (read_yn, chat_no, message, send_at, sender, sender_id) VALUES (false, 57, '당신 누구야', '2024-02-16 00:55:47.210295', '신시원', '335');
INSERT INTO manitodb.tbl_chat_message (read_yn, chat_no, message, send_at, sender, sender_id) VALUES (false, 56, '발표 화이팅이다~', '2024-02-16 00:55:49.401680', '이상학', '366');
INSERT INTO manitodb.tbl_chat_message (read_yn, chat_no, message, send_at, sender, sender_id) VALUES (false, 56, 'A805화이팅', '2024-02-16 00:55:53.111413', '김현창', '365');
INSERT INTO manitodb.tbl_chat_message (read_yn, chat_no, message, send_at, sender, sender_id) VALUES (false, 56, '야호', '2024-02-16 00:55:56.649728', '고영이', '367');
INSERT INTO manitodb.tbl_chat_message (read_yn, chat_no, message, send_at, sender, sender_id) VALUES (false, 56, '화이팅~', '2024-02-16 00:55:57.650427', '신시원', '335');
INSERT INTO manitodb.tbl_chat_message (read_yn, chat_no, message, send_at, sender, sender_id) VALUES (false, 58, 'WHO ARE YOU', '2024-02-16 00:56:01.215533', '김현창', '365');
INSERT INTO manitodb.tbl_chat_message (read_yn, chat_no, message, send_at, sender, sender_id) VALUES (false, 61, '안녕하세요', '2024-02-16 00:56:04.781819', '김현창', '365');
INSERT INTO manitodb.tbl_chat_message (read_yn, chat_no, message, send_at, sender, sender_id) VALUES (false, 61, 'I\'M YOUR MANITO', '2024-02-16 00:56:13.404997', '김현창', '365');
INSERT INTO manitodb.tbl_chat_message (read_yn, chat_no, message, send_at, sender, sender_id) VALUES (false, 56, '팔자개 화이팅', '2024-02-16 00:56:18.817466', '이상학', '366');
INSERT INTO manitodb.tbl_chat_message (read_yn, chat_no, message, send_at, sender, sender_id) VALUES (false, 63, '안녕 나의 마니띠', '2024-02-16 01:13:07.892620', '고영이', '370');
INSERT INTO manitodb.tbl_chat_message (read_yn, chat_no, message, send_at, sender, sender_id) VALUES (false, 66, '안녕 내 마니띠', '2024-02-16 01:13:08.577755', '신시원', '369');
INSERT INTO manitodb.tbl_chat_message (read_yn, chat_no, message, send_at, sender, sender_id) VALUES (false, 63, '당신 누구야', '2024-02-16 01:13:13.779645', '신시원', '369');
INSERT INTO manitodb.tbl_chat_message (read_yn, chat_no, message, send_at, sender, sender_id) VALUES (false, 66, '안녕하세요', '2024-02-16 01:13:16.655630', '김현창', '372');
INSERT INTO manitodb.tbl_chat_message (read_yn, chat_no, message, send_at, sender, sender_id) VALUES (false, 62, 'gdgd', '2024-02-16 01:13:20.598980', '이상학', '371');
INSERT INTO manitodb.tbl_chat_message (read_yn, chat_no, message, send_at, sender, sender_id) VALUES (false, 63, '뭐야', '2024-02-16 01:13:21.509120', '고영이', '370');
INSERT INTO manitodb.tbl_chat_message (read_yn, chat_no, message, send_at, sender, sender_id) VALUES (false, 66, '저의 마니또님이신가요', '2024-02-16 01:13:21.644128', '김현창', '372');
INSERT INTO manitodb.tbl_chat_message (read_yn, chat_no, message, send_at, sender, sender_id) VALUES (false, 66, '안녕하세요', '2024-02-16 01:13:21.901245', '신시원', '369');
INSERT INTO manitodb.tbl_chat_message (read_yn, chat_no, message, send_at, sender, sender_id) VALUES (false, 62, 'ㅎㅇㅎㅇ', '2024-02-16 01:13:23.128260', '이상학', '371');
INSERT INTO manitodb.tbl_chat_message (read_yn, chat_no, message, send_at, sender, sender_id) VALUES (false, 62, '반가워요', '2024-02-16 01:13:25.021033', '신시원', '369');
INSERT INTO manitodb.tbl_chat_message (read_yn, chat_no, message, send_at, sender, sender_id) VALUES (false, 62, '신나요', '2024-02-16 01:13:28.752855', '고영이', '370');
INSERT INTO manitodb.tbl_chat_message (read_yn, chat_no, message, send_at, sender, sender_id) VALUES (false, 66, '저는 초밥이면 좋겠어요', '2024-02-16 01:13:31.914664', '김현창', '372');
INSERT INTO manitodb.tbl_chat_message (read_yn, chat_no, message, send_at, sender, sender_id) VALUES (false, 62, '잠와요', '2024-02-16 01:13:34.031644', '이상학', '371');
INSERT INTO manitodb.tbl_chat_message (read_yn, chat_no, message, send_at, sender, sender_id) VALUES (false, 62, '안녕하세요', '2024-02-16 01:13:38.878711', '김현창', '372');
