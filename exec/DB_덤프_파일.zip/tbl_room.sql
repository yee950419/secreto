create table tbl_room
(
    common_yn           bit          null,
    host_participant_yn bit          null,
    mission_start_at    date         null,
    mission_submit_time time(6)      null,
    room_start_yn       bit          null,
    host_no             bigint       null,
    room_end_at         datetime(6)  null,
    room_no             bigint auto_increment
        primary key,
    room_start_at       datetime(6)  null,
    entry_code          varchar(255) null,
    room_name           varchar(255) null
);

INSERT INTO manitodb.tbl_room (common_yn, host_participant_yn, mission_start_at, mission_submit_time, room_start_yn, host_no, room_end_at, room_start_at, entry_code, room_name) VALUES (null, null, null, null, false, 306, '2024-02-22 20:29:00.179495', null, 'Zb7nMX', '마니또방');
INSERT INTO manitodb.tbl_room (common_yn, host_participant_yn, mission_start_at, mission_submit_time, room_start_yn, host_no, room_end_at, room_start_at, entry_code, room_name) VALUES (false, true, '2024-02-15', '11:00:00', true, 307, '2024-02-15 23:58:00.016378', '2024-02-15 21:05:40.685507', null, 'A805테스트');
INSERT INTO manitodb.tbl_room (common_yn, host_participant_yn, mission_start_at, mission_submit_time, room_start_yn, host_no, room_end_at, room_start_at, entry_code, room_name) VALUES (false, true, '2024-02-15', '10:00:00', true, 316, '2024-02-29 22:00:00.000000', '2024-02-15 22:15:07.960285', 'yPSYuf', '시크리또');
INSERT INTO manitodb.tbl_room (common_yn, host_participant_yn, mission_start_at, mission_submit_time, room_start_yn, host_no, room_end_at, room_start_at, entry_code, room_name) VALUES (null, null, null, null, false, 322, '2024-02-22 23:16:29.205128', null, 'xjINhd', '시크리또');
INSERT INTO manitodb.tbl_room (common_yn, host_participant_yn, mission_start_at, mission_submit_time, room_start_yn, host_no, room_end_at, room_start_at, entry_code, room_name) VALUES (false, true, '2024-02-16', '23:00:00', true, 327, '2024-02-15 23:58:00.030449', '2024-02-15 23:22:04.092109', null, '시크리또2');
INSERT INTO manitodb.tbl_room (common_yn, host_participant_yn, mission_start_at, mission_submit_time, room_start_yn, host_no, room_end_at, room_start_at, entry_code, room_name) VALUES (null, null, null, null, false, 328, '2024-02-22 23:21:19.340495', null, 'QyrM4X', '시크리또3');
INSERT INTO manitodb.tbl_room (common_yn, host_participant_yn, mission_start_at, mission_submit_time, room_start_yn, host_no, room_end_at, room_start_at, entry_code, room_name) VALUES (true, false, '2024-02-16', '23:00:00', true, 333, '2024-02-15 23:58:00.040317', '2024-02-15 23:42:41.642593', null, '시크리또2');
INSERT INTO manitodb.tbl_room (common_yn, host_participant_yn, mission_start_at, mission_submit_time, room_start_yn, host_no, room_end_at, room_start_at, entry_code, room_name) VALUES (true, true, '2024-02-16', '00:00:00', true, 335, '2024-02-16 00:58:00.074036', '2024-02-16 00:53:10.686673', null, '시크리또');
INSERT INTO manitodb.tbl_room (common_yn, host_participant_yn, mission_start_at, mission_submit_time, room_start_yn, host_no, room_end_at, room_start_at, entry_code, room_name) VALUES (true, false, '2024-02-16', '00:00:00', true, 345, '2024-02-29 00:00:00.000000', '2024-02-16 00:03:06.965017', 'BnsJk4', '히스토리용');
INSERT INTO manitodb.tbl_room (common_yn, host_participant_yn, mission_start_at, mission_submit_time, room_start_yn, host_no, room_end_at, room_start_at, entry_code, room_name) VALUES (true, true, '2024-02-16', '00:00:00', true, 346, '2024-02-29 00:00:00.000000', '2024-02-16 00:13:37.249280', 'tENagz', '히스토리');
INSERT INTO manitodb.tbl_room (common_yn, host_participant_yn, mission_start_at, mission_submit_time, room_start_yn, host_no, room_end_at, room_start_at, entry_code, room_name) VALUES (false, true, '2024-02-13', '00:00:00', true, 352, '2024-02-16 00:58:00.081715', '2024-02-16 00:24:14.676538', null, '히스토리방');
INSERT INTO manitodb.tbl_room (common_yn, host_participant_yn, mission_start_at, mission_submit_time, room_start_yn, host_no, room_end_at, room_start_at, entry_code, room_name) VALUES (false, true, '2024-02-13', '00:00:00', true, 358, '2024-02-16 00:58:44.849893', '2024-02-13 00:28:17.125000', null, '히스토리시연');
INSERT INTO manitodb.tbl_room (common_yn, host_participant_yn, mission_start_at, mission_submit_time, room_start_yn, host_no, room_end_at, room_start_at, entry_code, room_name) VALUES (null, null, null, null, false, 364, '2024-02-23 00:51:59.218192', null, 'i4d96y', '시크리또');
INSERT INTO manitodb.tbl_room (common_yn, host_participant_yn, mission_start_at, mission_submit_time, room_start_yn, host_no, room_end_at, room_start_at, entry_code, room_name) VALUES (false, true, '2024-02-16', '01:00:00', true, 369, '2024-02-16 01:34:00.031256', '2024-02-16 01:10:14.171450', null, '시크리또 시연');
