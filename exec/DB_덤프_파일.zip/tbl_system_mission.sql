create table tbl_system_mission
(
    system_mission_no bigint auto_increment
        primary key,
    content           text null
);

INSERT INTO manitodb.tbl_system_mission (content) VALUES ('사진을 통해 현재 기분을 표현해보기.');
INSERT INTO manitodb.tbl_system_mission (content) VALUES ('서로의 공통된 취향 나눠보기');
INSERT INTO manitodb.tbl_system_mission (content) VALUES ('만약 마니띠라면 어떻게 할지 이야기 해보기');
INSERT INTO manitodb.tbl_system_mission (content) VALUES ('시간을 되돌릴 수 있을 때 이야기 해보기');
INSERT INTO manitodb.tbl_system_mission (content) VALUES ('나의 특징 중 진짜 2개, 가짜 1개 이야기 하기');
INSERT INTO manitodb.tbl_system_mission (content) VALUES ('한 마디 인사를 전하고 서로의 하루를 공유하기.');
INSERT INTO manitodb.tbl_system_mission (content) VALUES ('그리고 싶은 그림 그려주기');
INSERT INTO manitodb.tbl_system_mission (content) VALUES ('닉네임으로 N행시 짓기');
INSERT INTO manitodb.tbl_system_mission (content) VALUES ('마니또에게 들려주고 싶은 음악 알려주기');
INSERT INTO manitodb.tbl_system_mission (content) VALUES ('나의 신체 일부로 힌트 주기');
INSERT INTO manitodb.tbl_system_mission (content) VALUES ('나의 최애 음식 소개하기');
INSERT INTO manitodb.tbl_system_mission (content) VALUES ('본인의 TMI 말해주기');
INSERT INTO manitodb.tbl_system_mission (content) VALUES ('나의 마니또에게 내가 누구인지 힌트 주기');
INSERT INTO manitodb.tbl_system_mission (content) VALUES ('내돈내산한 아이템 추천 하기');
INSERT INTO manitodb.tbl_system_mission (content) VALUES ('최근 감명 깊게 본 영화 이야기 해주기');
INSERT INTO manitodb.tbl_system_mission (content) VALUES ('마니또에게 소원을 말해봐');
INSERT INTO manitodb.tbl_system_mission (content) VALUES ('주말에 같이 게임하기');
INSERT INTO manitodb.tbl_system_mission (content) VALUES ('오늘의 점심 공유하기');
INSERT INTO manitodb.tbl_system_mission (content) VALUES ('민트초코 먹고 인증하기');
INSERT INTO manitodb.tbl_system_mission (content) VALUES ('나의 흑역사 공개하기');
