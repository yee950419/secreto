create table tbl_mission_schedule
(
    mission_submit_at   datetime(6) null,
    mission_schedule_no bigint auto_increment
        primary key,
    room_no             bigint      null,
    constraint FKmpuewedd640k53lcas9v5ny9v
        foreign key (room_no) references tbl_room (room_no)
);

INSERT INTO manitodb.tbl_mission_schedule (mission_submit_at, room_no) VALUES ('2024-02-15 11:00:00.000000', 108);
INSERT INTO manitodb.tbl_mission_schedule (mission_submit_at, room_no) VALUES ('2024-02-15 10:00:00.000000', 109);
INSERT INTO manitodb.tbl_mission_schedule (mission_submit_at, room_no) VALUES ('2024-02-16 10:00:00.000000', 109);
INSERT INTO manitodb.tbl_mission_schedule (mission_submit_at, room_no) VALUES ('2024-02-17 10:00:00.000000', 109);
INSERT INTO manitodb.tbl_mission_schedule (mission_submit_at, room_no) VALUES ('2024-02-18 10:00:00.000000', 109);
INSERT INTO manitodb.tbl_mission_schedule (mission_submit_at, room_no) VALUES ('2024-02-19 10:00:00.000000', 109);
INSERT INTO manitodb.tbl_mission_schedule (mission_submit_at, room_no) VALUES ('2024-02-20 10:00:00.000000', 109);
INSERT INTO manitodb.tbl_mission_schedule (mission_submit_at, room_no) VALUES ('2024-02-21 10:00:00.000000', 109);
INSERT INTO manitodb.tbl_mission_schedule (mission_submit_at, room_no) VALUES ('2024-02-22 10:00:00.000000', 109);
INSERT INTO manitodb.tbl_mission_schedule (mission_submit_at, room_no) VALUES ('2024-02-23 10:00:00.000000', 109);
INSERT INTO manitodb.tbl_mission_schedule (mission_submit_at, room_no) VALUES ('2024-02-24 10:00:00.000000', 109);
INSERT INTO manitodb.tbl_mission_schedule (mission_submit_at, room_no) VALUES ('2024-02-25 10:00:00.000000', 109);
INSERT INTO manitodb.tbl_mission_schedule (mission_submit_at, room_no) VALUES ('2024-02-26 10:00:00.000000', 109);
INSERT INTO manitodb.tbl_mission_schedule (mission_submit_at, room_no) VALUES ('2024-02-27 10:00:00.000000', 109);
INSERT INTO manitodb.tbl_mission_schedule (mission_submit_at, room_no) VALUES ('2024-02-28 10:00:00.000000', 109);
INSERT INTO manitodb.tbl_mission_schedule (mission_submit_at, room_no) VALUES ('2024-02-16 23:00:00.000000', 113);
INSERT INTO manitodb.tbl_mission_schedule (mission_submit_at, room_no) VALUES ('2024-02-23 23:00:00.000000', 113);
INSERT INTO manitodb.tbl_mission_schedule (mission_submit_at, room_no) VALUES ('2024-02-16 00:00:00.000000', 115);
INSERT INTO manitodb.tbl_mission_schedule (mission_submit_at, room_no) VALUES ('2024-02-17 00:00:00.000000', 115);
INSERT INTO manitodb.tbl_mission_schedule (mission_submit_at, room_no) VALUES ('2024-02-18 00:00:00.000000', 115);
INSERT INTO manitodb.tbl_mission_schedule (mission_submit_at, room_no) VALUES ('2024-02-19 00:00:00.000000', 115);
INSERT INTO manitodb.tbl_mission_schedule (mission_submit_at, room_no) VALUES ('2024-02-20 00:00:00.000000', 115);
INSERT INTO manitodb.tbl_mission_schedule (mission_submit_at, room_no) VALUES ('2024-02-21 00:00:00.000000', 115);
INSERT INTO manitodb.tbl_mission_schedule (mission_submit_at, room_no) VALUES ('2024-02-22 00:00:00.000000', 115);
INSERT INTO manitodb.tbl_mission_schedule (mission_submit_at, room_no) VALUES ('2024-02-23 00:00:00.000000', 115);
INSERT INTO manitodb.tbl_mission_schedule (mission_submit_at, room_no) VALUES ('2024-02-24 00:00:00.000000', 115);
INSERT INTO manitodb.tbl_mission_schedule (mission_submit_at, room_no) VALUES ('2024-02-25 00:00:00.000000', 115);
INSERT INTO manitodb.tbl_mission_schedule (mission_submit_at, room_no) VALUES ('2024-02-26 00:00:00.000000', 115);
INSERT INTO manitodb.tbl_mission_schedule (mission_submit_at, room_no) VALUES ('2024-02-27 00:00:00.000000', 115);
INSERT INTO manitodb.tbl_mission_schedule (mission_submit_at, room_no) VALUES ('2024-02-28 00:00:00.000000', 115);
INSERT INTO manitodb.tbl_mission_schedule (mission_submit_at, room_no) VALUES ('2024-02-16 00:00:00.000000', 116);
INSERT INTO manitodb.tbl_mission_schedule (mission_submit_at, room_no) VALUES ('2024-02-17 00:00:00.000000', 116);
INSERT INTO manitodb.tbl_mission_schedule (mission_submit_at, room_no) VALUES ('2024-02-18 00:00:00.000000', 116);
INSERT INTO manitodb.tbl_mission_schedule (mission_submit_at, room_no) VALUES ('2024-02-19 00:00:00.000000', 116);
INSERT INTO manitodb.tbl_mission_schedule (mission_submit_at, room_no) VALUES ('2024-02-20 00:00:00.000000', 116);
INSERT INTO manitodb.tbl_mission_schedule (mission_submit_at, room_no) VALUES ('2024-02-21 00:00:00.000000', 116);
INSERT INTO manitodb.tbl_mission_schedule (mission_submit_at, room_no) VALUES ('2024-02-22 00:00:00.000000', 116);
INSERT INTO manitodb.tbl_mission_schedule (mission_submit_at, room_no) VALUES ('2024-02-23 00:00:00.000000', 116);
INSERT INTO manitodb.tbl_mission_schedule (mission_submit_at, room_no) VALUES ('2024-02-24 00:00:00.000000', 116);
INSERT INTO manitodb.tbl_mission_schedule (mission_submit_at, room_no) VALUES ('2024-02-25 00:00:00.000000', 116);
INSERT INTO manitodb.tbl_mission_schedule (mission_submit_at, room_no) VALUES ('2024-02-26 00:00:00.000000', 116);
INSERT INTO manitodb.tbl_mission_schedule (mission_submit_at, room_no) VALUES ('2024-02-27 00:00:00.000000', 116);
INSERT INTO manitodb.tbl_mission_schedule (mission_submit_at, room_no) VALUES ('2024-02-28 00:00:00.000000', 116);
INSERT INTO manitodb.tbl_mission_schedule (mission_submit_at, room_no) VALUES ('2024-02-16 00:00:00.000000', 118);
INSERT INTO manitodb.tbl_mission_schedule (mission_submit_at, room_no) VALUES ('2024-02-17 00:00:00.000000', 118);
INSERT INTO manitodb.tbl_mission_schedule (mission_submit_at, room_no) VALUES ('2024-02-18 00:00:00.000000', 118);
INSERT INTO manitodb.tbl_mission_schedule (mission_submit_at, room_no) VALUES ('2024-02-19 00:00:00.000000', 118);
INSERT INTO manitodb.tbl_mission_schedule (mission_submit_at, room_no) VALUES ('2024-02-20 00:00:00.000000', 118);
INSERT INTO manitodb.tbl_mission_schedule (mission_submit_at, room_no) VALUES ('2024-02-21 00:00:00.000000', 118);
INSERT INTO manitodb.tbl_mission_schedule (mission_submit_at, room_no) VALUES ('2024-02-22 00:00:00.000000', 118);
INSERT INTO manitodb.tbl_mission_schedule (mission_submit_at, room_no) VALUES ('2024-02-23 00:00:00.000000', 118);
INSERT INTO manitodb.tbl_mission_schedule (mission_submit_at, room_no) VALUES ('2024-02-24 00:00:00.000000', 118);
INSERT INTO manitodb.tbl_mission_schedule (mission_submit_at, room_no) VALUES ('2024-02-25 00:00:00.000000', 118);
INSERT INTO manitodb.tbl_mission_schedule (mission_submit_at, room_no) VALUES ('2024-02-26 00:00:00.000000', 118);
INSERT INTO manitodb.tbl_mission_schedule (mission_submit_at, room_no) VALUES ('2024-02-27 00:00:00.000000', 118);
INSERT INTO manitodb.tbl_mission_schedule (mission_submit_at, room_no) VALUES ('2024-02-28 00:00:00.000000', 118);
INSERT INTO manitodb.tbl_mission_schedule (mission_submit_at, room_no) VALUES ('2024-02-16 00:00:00.000000', 114);
INSERT INTO manitodb.tbl_mission_schedule (mission_submit_at, room_no) VALUES ('2024-02-17 00:00:00.000000', 114);
INSERT INTO manitodb.tbl_mission_schedule (mission_submit_at, room_no) VALUES ('2024-02-18 00:00:00.000000', 114);
INSERT INTO manitodb.tbl_mission_schedule (mission_submit_at, room_no) VALUES ('2024-02-19 00:00:00.000000', 114);
INSERT INTO manitodb.tbl_mission_schedule (mission_submit_at, room_no) VALUES ('2024-02-20 00:00:00.000000', 114);
INSERT INTO manitodb.tbl_mission_schedule (mission_submit_at, room_no) VALUES ('2024-02-21 00:00:00.000000', 114);
INSERT INTO manitodb.tbl_mission_schedule (mission_submit_at, room_no) VALUES ('2024-02-22 00:00:00.000000', 114);
INSERT INTO manitodb.tbl_mission_schedule (mission_submit_at, room_no) VALUES ('2024-02-23 00:00:00.000000', 114);
INSERT INTO manitodb.tbl_mission_schedule (mission_submit_at, room_no) VALUES ('2024-02-24 00:00:00.000000', 114);
INSERT INTO manitodb.tbl_mission_schedule (mission_submit_at, room_no) VALUES ('2024-02-25 00:00:00.000000', 114);
INSERT INTO manitodb.tbl_mission_schedule (mission_submit_at, room_no) VALUES ('2024-02-26 00:00:00.000000', 114);
INSERT INTO manitodb.tbl_mission_schedule (mission_submit_at, room_no) VALUES ('2024-02-27 00:00:00.000000', 114);
INSERT INTO manitodb.tbl_mission_schedule (mission_submit_at, room_no) VALUES ('2024-02-28 00:00:00.000000', 114);
INSERT INTO manitodb.tbl_mission_schedule (mission_submit_at, room_no) VALUES ('2024-02-16 01:00:00.000000', 120);
INSERT INTO manitodb.tbl_mission_schedule (mission_submit_at, room_no) VALUES ('2024-02-17 01:00:00.000000', 120);
INSERT INTO manitodb.tbl_mission_schedule (mission_submit_at, room_no) VALUES ('2024-02-18 01:00:00.000000', 120);
INSERT INTO manitodb.tbl_mission_schedule (mission_submit_at, room_no) VALUES ('2024-02-19 01:00:00.000000', 120);
INSERT INTO manitodb.tbl_mission_schedule (mission_submit_at, room_no) VALUES ('2024-02-20 01:00:00.000000', 120);
INSERT INTO manitodb.tbl_mission_schedule (mission_submit_at, room_no) VALUES ('2024-02-21 01:00:00.000000', 120);
INSERT INTO manitodb.tbl_mission_schedule (mission_submit_at, room_no) VALUES ('2024-02-22 01:00:00.000000', 120);
INSERT INTO manitodb.tbl_mission_schedule (mission_submit_at, room_no) VALUES ('2024-02-23 01:00:00.000000', 120);
INSERT INTO manitodb.tbl_mission_schedule (mission_submit_at, room_no) VALUES ('2024-02-24 01:00:00.000000', 120);
INSERT INTO manitodb.tbl_mission_schedule (mission_submit_at, room_no) VALUES ('2024-02-25 01:00:00.000000', 120);
INSERT INTO manitodb.tbl_mission_schedule (mission_submit_at, room_no) VALUES ('2024-02-26 01:00:00.000000', 120);
INSERT INTO manitodb.tbl_mission_schedule (mission_submit_at, room_no) VALUES ('2024-02-27 01:00:00.000000', 120);
INSERT INTO manitodb.tbl_mission_schedule (mission_submit_at, room_no) VALUES ('2024-02-28 01:00:00.000000', 120);
